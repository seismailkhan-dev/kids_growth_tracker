// lib/features/growth/data/datasources/growth_remote_datasource.dart

import 'package:cloud_firestore/cloud_firestore.dart';
import '../../domain/entities/growth_record_entity.dart';

abstract class GrowthRemoteDataSource {
  Future<List<GrowthRecordEntity>> getGrowthRecords(String childId);
  Future<GrowthRecordEntity> addGrowthRecord(GrowthRecordEntity record);
  Future<void> deleteGrowthRecord(String recordId);
}

class GrowthRemoteDataSourceImpl implements GrowthRemoteDataSource {
  final FirebaseFirestore _db = FirebaseFirestore.instance;

  @override
  Future<List<GrowthRecordEntity>> getGrowthRecords(String childId) async {
    final snapshot = await _db
        .collection('growth_records')
        .where('childId', isEqualTo: childId)
        .orderBy('recordedAt', descending: false)
        .get();
    return snapshot.docs
        .map((d) => GrowthRecordEntity.fromMap(d.data()))
        .toList();
  }

  @override
  Future<GrowthRecordEntity> addGrowthRecord(GrowthRecordEntity record) async {
    final docRef = _db.collection('growth_records').doc();
    final updated = GrowthRecordEntity(
      id: docRef.id,
      childId: record.childId,
      weight: record.weight,
      height: record.height,
      headCircumference: record.headCircumference,
      recordedAt: record.recordedAt,
      notes: record.notes,
    );
    await docRef.set(updated.toMap());
    return updated;
  }

  @override
  Future<void> deleteGrowthRecord(String recordId) async {
    await _db.collection('growth_records').doc(recordId).delete();
  }
}
