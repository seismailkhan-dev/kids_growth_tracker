// lib/features/growth/data/repositories/growth_repository_impl.dart
import 'package:dartz/dartz.dart';
import '../../domain/entities/growth_record_entity.dart';
import '../../domain/repositories/growth_repository.dart';
import '../datasources/growth_remote_datasource.dart';

class GrowthRepositoryImpl implements GrowthRepository {
  final GrowthRemoteDataSource _dataSource;
  GrowthRepositoryImpl(this._dataSource);

  @override
  Future<Either<String, List<GrowthRecordEntity>>> getGrowthRecords(String childId) async {
    try {
      return Right(await _dataSource.getGrowthRecords(childId));
    } catch (e) {
      return Left(e.toString());
    }
  }

  @override
  Future<Either<String, GrowthRecordEntity>> addGrowthRecord(GrowthRecordEntity record) async {
    try {
      return Right(await _dataSource.addGrowthRecord(record));
    } catch (e) {
      return Left(e.toString());
    }
  }

  @override
  Future<Either<String, void>> deleteGrowthRecord(String recordId) async {
    try {
      await _dataSource.deleteGrowthRecord(recordId);
      return const Right(null);
    } catch (e) {
      return Left(e.toString());
    }
  }
}
