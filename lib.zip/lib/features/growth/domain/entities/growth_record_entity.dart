// lib/features/growth/domain/entities/growth_record_entity.dart

class GrowthRecordEntity {
  final String id;
  final String childId;
  final double weight; // kg
  final double height; // cm
  final double? headCircumference; // cm
  final DateTime recordedAt;
  final String? notes;

  const GrowthRecordEntity({
    required this.id,
    required this.childId,
    required this.weight,
    required this.height,
    this.headCircumference,
    required this.recordedAt,
    this.notes,
  });

  Map<String, dynamic> toMap() => {
    'id': id,
    'childId': childId,
    'weight': weight,
    'height': height,
    'headCircumference': headCircumference,
    'recordedAt': recordedAt.toIso8601String(),
    'notes': notes,
  };

  factory GrowthRecordEntity.fromMap(Map<String, dynamic> map) => GrowthRecordEntity(
    id: map['id'] ?? '',
    childId: map['childId'] ?? '',
    weight: (map['weight'] ?? 0.0).toDouble(),
    height: (map['height'] ?? 0.0).toDouble(),
    headCircumference: map['headCircumference']?.toDouble(),
    recordedAt: DateTime.parse(map['recordedAt']),
    notes: map['notes'],
  );

  double get bmi => weight / ((height / 100) * (height / 100));
}
