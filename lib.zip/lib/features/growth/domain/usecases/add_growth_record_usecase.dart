// lib/features/growth/domain/usecases/add_growth_record_usecase.dart
import 'package:dartz/dartz.dart';
import '../entities/growth_record_entity.dart';
import '../repositories/growth_repository.dart';

class AddGrowthRecordUseCase {
  final GrowthRepository _repo;
  AddGrowthRecordUseCase(this._repo);
  Future<Either<String, GrowthRecordEntity>> call(GrowthRecordEntity record) =>
      _repo.addGrowthRecord(record);
}
