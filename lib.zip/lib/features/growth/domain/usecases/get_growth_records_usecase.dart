// lib/features/growth/domain/usecases/get_growth_records_usecase.dart
import 'package:dartz/dartz.dart';
import '../entities/growth_record_entity.dart';
import '../repositories/growth_repository.dart';

class GetGrowthRecordsUseCase {
  final GrowthRepository _repo;
  GetGrowthRecordsUseCase(this._repo);
  Future<Either<String, List<GrowthRecordEntity>>> call(String childId) =>
      _repo.getGrowthRecords(childId);
}
