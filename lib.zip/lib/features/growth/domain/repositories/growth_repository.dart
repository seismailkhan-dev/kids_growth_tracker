// lib/features/growth/domain/repositories/growth_repository.dart
import 'package:dartz/dartz.dart';
import '../entities/growth_record_entity.dart';

abstract class GrowthRepository {
  Future<Either<String, List<GrowthRecordEntity>>> getGrowthRecords(String childId);
  Future<Either<String, GrowthRecordEntity>> addGrowthRecord(GrowthRecordEntity record);
  Future<Either<String, void>> deleteGrowthRecord(String recordId);
}

