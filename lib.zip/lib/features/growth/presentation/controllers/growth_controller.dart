// lib/features/growth/presentation/controllers/growth_controller.dart

import 'package:get/get.dart';
import 'package:uuid/uuid.dart';
import '../../domain/entities/growth_record_entity.dart';
import '../../domain/usecases/get_growth_records_usecase.dart';
import '../../domain/usecases/add_growth_record_usecase.dart';
import '../../../child/domain/entities/child_entity.dart';

class GrowthController extends GetxController {
  final GetGrowthRecordsUseCase getGrowthRecords;
  final AddGrowthRecordUseCase addGrowthRecord;

  GrowthController({
    required this.getGrowthRecords,
    required this.addGrowthRecord,
  });

  final RxList<GrowthRecordEntity> records = <GrowthRecordEntity>[].obs;
  final RxBool isLoading = false.obs;
  Rx<ChildEntity?> selectedChild = Rx<ChildEntity?>(null);

  @override
  void onInit() {
    super.onInit();
    final child = Get.arguments as ChildEntity?;
    if (child != null) {
      selectedChild.value = child;
      loadRecords(child.id);
    }
  }

  Future<void> loadRecords(String childId) async {
    isLoading.value = true;
    final result = await getGrowthRecords(childId);
    result.fold(
      (e) => Get.snackbar('Error', e),
      (list) => records.assignAll(list),
    );
    isLoading.value = false;
  }

  Future<void> addRecord({
    required double weight,
    required double height,
    double? headCircumference,
    String? notes,
    DateTime? date,
  }) async {
    final child = selectedChild.value;
    if (child == null) return;

    final record = GrowthRecordEntity(
      id: const Uuid().v4(),
      childId: child.id,
      weight: weight,
      height: height,
      headCircumference: headCircumference,
      recordedAt: date ?? DateTime.now(),
      notes: notes,
    );

    isLoading.value = true;
    final result = await addGrowthRecord(record);
    result.fold(
      (e) => Get.snackbar('Error', e),
      (newRecord) {
        records.add(newRecord);
        records.sort((a, b) => a.recordedAt.compareTo(b.recordedAt));
      },
    );
    isLoading.value = false;
  }

  GrowthRecordEntity? get latestRecord =>
      records.isNotEmpty ? records.last : null;

  double? get weightChange {
    if (records.length < 2) return null;
    return records.last.weight - records[records.length - 2].weight;
  }

  double? get heightChange {
    if (records.length < 2) return null;
    return records.last.height - records[records.length - 2].height;
  }
}
