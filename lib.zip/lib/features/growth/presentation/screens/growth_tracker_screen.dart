// lib/features/growth/presentation/screens/growth_tracker_screen.dart

import 'package:flutter/material.dart';
import 'package:fl_chart/fl_chart.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import '../../../../core/constants/app_colors.dart';
import '../../../../core/widgets/app_card.dart';
import '../../../../core/widgets/loading_widget.dart';
import '../controllers/growth_controller.dart';

class GrowthTrackerScreen extends StatefulWidget {
  const GrowthTrackerScreen({super.key});

  @override
  State<GrowthTrackerScreen> createState() => _GrowthTrackerScreenState();
}

class _GrowthTrackerScreenState extends State<GrowthTrackerScreen>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;
  final _weightCtrl = TextEditingController();
  final _heightCtrl = TextEditingController();
  final _headCtrl = TextEditingController();
  final _notesCtrl = TextEditingController();

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
  }

  @override
  void dispose() {
    _tabController.dispose();
    _weightCtrl.dispose();
    _heightCtrl.dispose();
    _headCtrl.dispose();
    _notesCtrl.dispose();
    super.dispose();
  }

  void _showAddRecordSheet() {
    Get.bottomSheet(
      _AddGrowthRecordSheet(
        weightCtrl: _weightCtrl,
        heightCtrl: _heightCtrl,
        headCtrl: _headCtrl,
        notesCtrl: _notesCtrl,
      ),
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
    );
  }

  @override
  Widget build(BuildContext context) {
    final controller = Get.find<GrowthController>();

    return Scaffold(
      appBar: AppBar(
        title: Obx(() => Text(
          '${controller.selectedChild.value?.name ?? ''} Growth')),
        bottom: TabBar(
          controller: _tabController,
          tabs: const [
            Tab(text: 'Charts'),
            Tab(text: 'Records'),
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _showAddRecordSheet,
        icon: const Icon(Icons.add),
        label: const Text('Add Record'),
        backgroundColor: AppColors.primary,
        foregroundColor: Colors.white,
      ),
      body: Obx(() {
        if (controller.isLoading.value) {
          return const LoadingWidget(message: 'Loading growth data...');
        }
        return TabBarView(
          controller: _tabController,
          children: [
            _ChartsTab(controller: controller),
            _RecordsTab(controller: controller),
          ],
        );
      }),
    );
  }
}

class _ChartsTab extends StatelessWidget {
  final GrowthController controller;
  const _ChartsTab({required this.controller});

  @override
  Widget build(BuildContext context) {
    if (controller.records.isEmpty) {
      return const EmptyState(
        title: 'No Growth Records',
        message: 'Add the first measurement to start tracking growth',
        icon: Icons.show_chart,
      );
    }

    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        children: [
          // Stats row
          Row(
            children: [
              _StatCard(
                title: 'Weight',
                value: '${controller.latestRecord?.weight.toStringAsFixed(1) ?? '-'} kg',
                change: controller.weightChange,
                unit: 'kg',
                color: AppColors.primary,
              ),
              const SizedBox(width: 12),
              _StatCard(
                title: 'Height',
                value: '${controller.latestRecord?.height.toStringAsFixed(1) ?? '-'} cm',
                change: controller.heightChange,
                unit: 'cm',
                color: AppColors.secondary,
              ),
            ],
          ),
          const SizedBox(height: 16),

          // Weight chart
          AppCard(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('Weight Over Time', style: Theme.of(context).textTheme.titleLarge),
                const SizedBox(height: 16),
                SizedBox(
                  height: 200,
                  child: _buildLineChart(
                    controller.records.map((r) => FlSpot(
                      r.recordedAt.millisecondsSinceEpoch.toDouble(),
                      r.weight,
                    )).toList(),
                    AppColors.primary,
                    'kg',
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 16),

          // Height chart
          AppCard(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('Height Over Time', style: Theme.of(context).textTheme.titleLarge),
                const SizedBox(height: 16),
                SizedBox(
                  height: 200,
                  child: _buildLineChart(
                    controller.records.map((r) => FlSpot(
                      r.recordedAt.millisecondsSinceEpoch.toDouble(),
                      r.height,
                    )).toList(),
                    AppColors.secondary,
                    'cm',
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildLineChart(List<FlSpot> spots, Color color, String unit) {
    if (spots.isEmpty) return const SizedBox();

    final minY = spots.map((s) => s.y).reduce((a, b) => a < b ? a : b) - 2;
    final maxY = spots.map((s) => s.y).reduce((a, b) => a > b ? a : b) + 2;

    return LineChart(
      LineChartData(
        gridData: FlGridData(
          show: true,
          drawVerticalLine: false,
          getDrawingHorizontalLine: (_) => FlLine(
            color: Colors.grey.withOpacity(0.15),
            strokeWidth: 1,
          ),
        ),
        titlesData: FlTitlesData(
          leftTitles: AxisTitles(
            sideTitles: SideTitles(
              showTitles: true,
              reservedSize: 40,
              getTitlesWidget: (v, _) => Text(
                v.toStringAsFixed(0),
                style: const TextStyle(fontSize: 10, color: AppColors.textHint),
              ),
            ),
          ),
          bottomTitles: AxisTitles(
            sideTitles: SideTitles(
              showTitles: true,
              reservedSize: 24,
              getTitlesWidget: (v, _) {
                final date = DateTime.fromMillisecondsSinceEpoch(v.toInt());
                return Text(
                  DateFormat('MMM').format(date),
                  style: const TextStyle(fontSize: 10, color: AppColors.textHint),
                );
              },
            ),
          ),
          rightTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
          topTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
        ),
        borderData: FlBorderData(show: false),
        minY: minY,
        maxY: maxY,
        lineBarsData: [
          LineChartBarData(
            spots: spots,
            isCurved: true,
            color: color,
            barWidth: 3,
            isStrokeCapRound: true,
            dotData: FlDotData(
              show: true,
              getDotPainter: (_, __, ___, ____) => FlDotCirclePainter(
                radius: 4,
                color: color,
                strokeWidth: 2,
                strokeColor: Colors.white,
              ),
            ),
            belowBarData: BarAreaData(
              show: true,
              color: color.withOpacity(0.1),
            ),
          ),
        ],
      ),
    );
  }
}

class _StatCard extends StatelessWidget {
  final String title;
  final String value;
  final double? change;
  final String unit;
  final Color color;

  const _StatCard({
    required this.title,
    required this.value,
    this.change,
    required this.unit,
    required this.color,
  });

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: color.withOpacity(0.1),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: color.withOpacity(0.2)),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(title, style: const TextStyle(fontSize: 13, color: AppColors.textSecondary)),
            const SizedBox(height: 4),
            Text(value, style: TextStyle(fontSize: 20, fontWeight: FontWeight.w700, color: color)),
            if (change != null) ...[
              const SizedBox(height: 4),
              Row(
                children: [
                  Icon(
                    change! >= 0 ? Icons.arrow_upward : Icons.arrow_downward,
                    size: 12,
                    color: change! >= 0 ? AppColors.success : AppColors.error,
                  ),
                  Text(
                    '${change!.abs().toStringAsFixed(1)} $unit',
                    style: TextStyle(
                      fontSize: 11,
                      color: change! >= 0 ? AppColors.success : AppColors.error,
                    ),
                  ),
                ],
              ),
            ],
          ],
        ),
      ),
    );
  }
}

class _RecordsTab extends StatelessWidget {
  final GrowthController controller;
  const _RecordsTab({required this.controller});

  @override
  Widget build(BuildContext context) {
    if (controller.records.isEmpty) {
      return const EmptyState(
        title: 'No Records Yet',
        message: 'Tap the button below to add the first measurement',
        icon: Icons.monitor_weight_outlined,
      );
    }

    return ListView.builder(
      padding: const EdgeInsets.all(16),
      itemCount: controller.records.length,
      itemBuilder: (context, i) {
        final record = controller.records.reversed.toList()[i];
        return AppCard(
          margin: const EdgeInsets.only(bottom: 12),
          child: Row(
            children: [
              Container(
                width: 48,
                height: 48,
                decoration: BoxDecoration(
                  color: AppColors.primary.withOpacity(0.1),
                  shape: BoxShape.circle,
                ),
                child: const Icon(Icons.monitor_weight, color: AppColors.primary),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      DateFormat('MMMM d, yyyy').format(record.recordedAt),
                      style: Theme.of(context).textTheme.titleMedium,
                    ),
                    const SizedBox(height: 4),
                    Row(
                      children: [
                        _Tag('${record.weight} kg', AppColors.primary),
                        const SizedBox(width: 8),
                        _Tag('${record.height} cm', AppColors.secondary),
                        if (record.headCircumference != null) ...[
                          const SizedBox(width: 8),
                          _Tag('HC: ${record.headCircumference} cm', AppColors.accent),
                        ],
                      ],
                    ),
                    if (record.notes != null && record.notes!.isNotEmpty) ...[
                      const SizedBox(height: 4),
                      Text(record.notes!, style: Theme.of(context).textTheme.bodySmall),
                    ],
                  ],
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}

class _Tag extends StatelessWidget {
  final String text;
  final Color color;
  const _Tag(this.text, this.color);

  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
    decoration: BoxDecoration(
      color: color.withOpacity(0.1),
      borderRadius: BorderRadius.circular(6),
    ),
    child: Text(text, style: TextStyle(color: color, fontSize: 11, fontWeight: FontWeight.w600)),
  );
}

class _AddGrowthRecordSheet extends StatelessWidget {
  final TextEditingController weightCtrl;
  final TextEditingController heightCtrl;
  final TextEditingController headCtrl;
  final TextEditingController notesCtrl;

  const _AddGrowthRecordSheet({
    required this.weightCtrl,
    required this.heightCtrl,
    required this.headCtrl,
    required this.notesCtrl,
  });

  @override
  Widget build(BuildContext context) {
    final controller = Get.find<GrowthController>();
    final formKey = GlobalKey<FormState>();

    return Container(
      decoration: const BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      padding: EdgeInsets.fromLTRB(
        24, 16, 24, MediaQuery.of(context).viewInsets.bottom + 24),
      child: Form(
        key: formKey,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Center(
              child: Container(
                width: 40,
                height: 4,
                decoration: BoxDecoration(
                  color: Colors.grey.shade300,
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
            ),
            const SizedBox(height: 16),
            Text('Add Growth Record', style: Theme.of(context).textTheme.headlineSmall),
            const SizedBox(height: 16),
            Row(
              children: [
                Expanded(
                  child: TextFormField(
                    controller: weightCtrl,
                    keyboardType: const TextInputType.numberWithOptions(decimal: true),
                    decoration: const InputDecoration(
                      labelText: 'Weight (kg)',
                      prefixIcon: Icon(Icons.monitor_weight_outlined),
                    ),
                    validator: (v) => v == null || v.isEmpty ? 'Required' : null,
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: TextFormField(
                    controller: heightCtrl,
                    keyboardType: const TextInputType.numberWithOptions(decimal: true),
                    decoration: const InputDecoration(
                      labelText: 'Height (cm)',
                      prefixIcon: Icon(Icons.straighten),
                    ),
                    validator: (v) => v == null || v.isEmpty ? 'Required' : null,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            TextFormField(
              controller: headCtrl,
              keyboardType: const TextInputType.numberWithOptions(decimal: true),
              decoration: const InputDecoration(
                labelText: 'Head Circumference cm (optional)',
                prefixIcon: Icon(Icons.face),
              ),
            ),
            const SizedBox(height: 12),
            TextFormField(
              controller: notesCtrl,
              decoration: const InputDecoration(
                labelText: 'Notes (optional)',
                prefixIcon: Icon(Icons.notes),
              ),
            ),
            const SizedBox(height: 20),
            Obx(() => ElevatedButton(
              onPressed: controller.isLoading.value
                  ? null
                  : () async {
                      if (!formKey.currentState!.validate()) return;
                      await controller.addRecord(
                        weight: double.parse(weightCtrl.text),
                        height: double.parse(heightCtrl.text),
                        headCircumference: headCtrl.text.isNotEmpty
                            ? double.parse(headCtrl.text)
                            : null,
                        notes: notesCtrl.text.isNotEmpty ? notesCtrl.text : null,
                      );
                      weightCtrl.clear();
                      heightCtrl.clear();
                      headCtrl.clear();
                      notesCtrl.clear();
                      Get.back();
                    },
              style: ElevatedButton.styleFrom(
                minimumSize: const Size(double.infinity, 52),
              ),
              child: controller.isLoading.value
                  ? const CircularProgressIndicator(color: Colors.white)
                  : const Text('Save Record'),
            )),
          ],
        ),
      ),
    );
  }
}
