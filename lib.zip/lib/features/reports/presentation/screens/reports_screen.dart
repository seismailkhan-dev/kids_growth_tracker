// lib/features/reports/presentation/screens/reports_screen.dart

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../../../core/constants/app_colors.dart';
import '../../../../core/widgets/app_card.dart';
import '../../../subscription/presentation/controllers/subscription_controller.dart';
import '../../../../core/routes/app_pages.dart';

class ReportsScreen extends StatelessWidget {
  const ReportsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final subController = Get.find<SubscriptionController>();

    if (!subController.isPremium.value) {
      WidgetsBinding.instance.addPostFrameCallback(
          (_) => Get.offNamed(Routes.subscription));
    }

    return Scaffold(
      appBar: AppBar(title: const Text('Health Reports')),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Generate Reports', style: Theme.of(context).textTheme.headlineSmall),
            const SizedBox(height: 8),
            Text(
              'Export detailed health reports as PDF for your child\'s records',
              style: Theme.of(context).textTheme.bodyMedium,
            ),
            const SizedBox(height: 24),
            _ReportCard(
              title: 'Growth Report',
              description: 'Height, weight, and BMI trends over time',
              icon: Icons.show_chart,
              color: AppColors.primary,
              onGenerate: () => _generateReport('Growth'),
            ),
            const SizedBox(height: 12),
            _ReportCard(
              title: 'Sleep Analysis',
              description: 'Sleep duration and quality patterns',
              icon: Icons.bedtime,
              color: AppColors.lightBlue,
              onGenerate: () => _generateReport('Sleep'),
            ),
            const SizedBox(height: 12),
            _ReportCard(
              title: 'Medical Summary',
              description: 'Doctor visits, vaccinations, and health history',
              icon: Icons.medical_services_outlined,
              color: AppColors.secondary,
              onGenerate: () => _generateReport('Medical'),
            ),
            const SizedBox(height: 12),
            _ReportCard(
              title: 'Complete Health Report',
              description: 'All data combined in one comprehensive report',
              icon: Icons.description,
              color: AppColors.accent,
              onGenerate: () => _generateReport('Complete'),
            ),
          ],
        ),
      ),
    );
  }

  void _generateReport(String type) {
    Get.snackbar(
      'Generating Report',
      '$type report is being generated...',
      snackPosition: SnackPosition.BOTTOM,
      backgroundColor: AppColors.primary,
      colorText: Colors.white,
      icon: const Icon(Icons.picture_as_pdf, color: Colors.white),
    );
    // TODO: Integrate with pdf package to generate actual PDF
    // Use printing package to share/download
  }
}

class _ReportCard extends StatelessWidget {
  final String title;
  final String description;
  final IconData icon;
  final Color color;
  final VoidCallback onGenerate;

  const _ReportCard({
    required this.title,
    required this.description,
    required this.icon,
    required this.color,
    required this.onGenerate,
  });

  @override
  Widget build(BuildContext context) {
    return AppCard(
      onTap: onGenerate,
      child: Row(
        children: [
          Container(
            width: 52,
            height: 52,
            decoration: BoxDecoration(
              color: color.withOpacity(0.1),
              borderRadius: BorderRadius.circular(14),
            ),
            child: Icon(icon, color: color, size: 28),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title, style: Theme.of(context).textTheme.titleLarge),
                const SizedBox(height: 4),
                Text(description, style: Theme.of(context).textTheme.bodySmall),
              ],
            ),
          ),
          const Icon(Icons.picture_as_pdf, color: AppColors.textHint),
        ],
      ),
    );
  }
}
