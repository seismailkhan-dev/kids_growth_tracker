// lib/features/auth/data/datasources/auth_remote_datasource.dart

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:google_sign_in/google_sign_in.dart';
import '../../domain/entities/user_entity.dart';

abstract class AuthRemoteDataSource {
  Stream<UserEntity?> get authStateChanges;
  Future<UserEntity> login(String email, String password);
  Future<UserEntity> signup(String email, String password, String name);
  Future<UserEntity> signInWithGoogle();
  Future<void> logout();
  Future<void> sendPasswordReset(String email);
  Future<UserEntity?> getCurrentUser();
}

class AuthRemoteDataSourceImpl implements AuthRemoteDataSource {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  final GoogleSignIn _googleSignIn = GoogleSignIn();

  @override
  Stream<UserEntity?> get authStateChanges =>
      _auth.authStateChanges().asyncMap((user) async {
        if (user == null) return null;
        return await _fetchUserEntity(user.uid);
      });

  @override
  Future<UserEntity> login(String email, String password) async {
    final cred = await _auth.signInWithEmailAndPassword(
      email: email,
      password: password,
    );
    return await _fetchUserEntity(cred.user!.uid);
  }

  @override
  Future<UserEntity> signup(String email, String password, String name) async {
    final cred = await _auth.createUserWithEmailAndPassword(
      email: email,
      password: password,
    );
    await cred.user!.updateDisplayName(name);

    final user = UserEntity(
      uid: cred.user!.uid,
      email: email,
      displayName: name,
      isPremium: false,
      createdAt: DateTime.now(),
    );

    // Save user to Firestore
    await _firestore.collection('users').doc(user.uid).set({
      'uid': user.uid,
      'email': user.email,
      'displayName': user.displayName,
      'isPremium': false,
      'createdAt': FieldValue.serverTimestamp(),
    });

    return user;
  }

  @override
  Future<UserEntity> signInWithGoogle() async {
    final googleUser = await _googleSignIn.signIn();
    if (googleUser == null) throw Exception('Google sign in cancelled');

    final googleAuth = await googleUser.authentication;
    final credential = GoogleAuthProvider.credential(
      accessToken: googleAuth.accessToken,
      idToken: googleAuth.idToken,
    );

    final cred = await _auth.signInWithCredential(credential);
    final uid = cred.user!.uid;

    // Create or update user in Firestore
    final doc = await _firestore.collection('users').doc(uid).get();
    if (!doc.exists) {
      await _firestore.collection('users').doc(uid).set({
        'uid': uid,
        'email': cred.user!.email,
        'displayName': cred.user!.displayName,
        'photoUrl': cred.user!.photoURL,
        'isPremium': false,
        'createdAt': FieldValue.serverTimestamp(),
      });
    }

    return await _fetchUserEntity(uid);
  }

  @override
  Future<void> logout() async {
    await _googleSignIn.signOut();
    await _auth.signOut();
  }

  @override
  Future<void> sendPasswordReset(String email) async {
    await _auth.sendPasswordResetEmail(email: email);
  }

  @override
  Future<UserEntity?> getCurrentUser() async {
    final user = _auth.currentUser;
    if (user == null) return null;
    return await _fetchUserEntity(user.uid);
  }

  Future<UserEntity> _fetchUserEntity(String uid) async {
    final doc = await _firestore.collection('users').doc(uid).get();
    if (doc.exists) {
      final data = doc.data()!;
      return UserEntity(
        uid: uid,
        email: data['email'] ?? '',
        displayName: data['displayName'],
        photoUrl: data['photoUrl'],
        isPremium: data['isPremium'] ?? false,
        createdAt: (data['createdAt'] as Timestamp?)?.toDate() ?? DateTime.now(),
      );
    }
    // Fallback
    final firebaseUser = _auth.currentUser!;
    return UserEntity(
      uid: uid,
      email: firebaseUser.email ?? '',
      displayName: firebaseUser.displayName,
      photoUrl: firebaseUser.photoURL,
      isPremium: false,
      createdAt: DateTime.now(),
    );
  }
}
