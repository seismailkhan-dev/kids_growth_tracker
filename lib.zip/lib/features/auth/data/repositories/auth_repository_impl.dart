// lib/features/auth/data/repositories/auth_repository_impl.dart

import 'package:dartz/dartz.dart';
import '../../domain/entities/user_entity.dart';
import '../../domain/repositories/auth_repository.dart';
import '../datasources/auth_remote_datasource.dart';

class AuthRepositoryImpl implements AuthRepository {
  final AuthRemoteDataSource _dataSource;
  AuthRepositoryImpl(this._dataSource);

  @override
  Stream<UserEntity?> get authStateChanges => _dataSource.authStateChanges;

  @override
  Future<Either<String, UserEntity>> login(String email, String password) async {
    try {
      final user = await _dataSource.login(email, password);
      return Right(user);
    } on Exception catch (e) {
      return Left(_handleError(e));
    }
  }

  @override
  Future<Either<String, UserEntity>> signup(
      String email, String password, String name) async {
    try {
      final user = await _dataSource.signup(email, password, name);
      return Right(user);
    } on Exception catch (e) {
      return Left(_handleError(e));
    }
  }

  @override
  Future<Either<String, UserEntity>> signInWithGoogle() async {
    try {
      final user = await _dataSource.signInWithGoogle();
      return Right(user);
    } on Exception catch (e) {
      return Left(_handleError(e));
    }
  }

  @override
  Future<Either<String, void>> logout() async {
    try {
      await _dataSource.logout();
      return const Right(null);
    } on Exception catch (e) {
      return Left(_handleError(e));
    }
  }

  @override
  Future<Either<String, void>> sendPasswordReset(String email) async {
    try {
      await _dataSource.sendPasswordReset(email);
      return const Right(null);
    } on Exception catch (e) {
      return Left(_handleError(e));
    }
  }

  @override
  Future<UserEntity?> getCurrentUser() => _dataSource.getCurrentUser();

  String _handleError(dynamic e) {
    if (e.toString().contains('wrong-password')) return 'Incorrect password.';
    if (e.toString().contains('user-not-found')) return 'No account found.';
    if (e.toString().contains('email-already-in-use')) return 'Email already in use.';
    if (e.toString().contains('weak-password')) return 'Password is too weak.';
    if (e.toString().contains('network-request-failed')) return 'No internet connection.';
    return 'Something went wrong. Please try again.';
  }
}
