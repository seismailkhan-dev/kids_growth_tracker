// lib/features/auth/presentation/controllers/auth_controller.dart

import 'package:get/get.dart';
import '../../domain/entities/user_entity.dart';
import '../../domain/usecases/login_usecase.dart';
import '../../domain/usecases/signup_usecase.dart';
import '../../domain/usecases/logout_usecase.dart';
import '../../domain/usecases/google_signin_usecase.dart';
import '../../domain/repositories/auth_repository.dart';
import '../../../../core/routes/app_pages.dart';
import '../../../../core/services/storage_service.dart';

class AuthController extends GetxController {


  final Rx<UserEntity?> currentUser = Rx<UserEntity?>(null);
  final RxBool isLoading = false.obs;
  final RxString errorMessage = ''.obs;

  @override
  void onInit() {
    super.onInit();
    // Listen to auth state changes
    ever(currentUser, _handleAuthChange);

    // Bind auth state stream
    // final repo = Get.find<AuthRepository>();
    // repo.authStateChanges.listen((user) {
    //   currentUser.value = user;
    // });
  }

  void _handleAuthChange(UserEntity? user) {
    if (user != null) {
      final storage = Get.find<StorageService>();
      final onboardingDone = storage.getBool('onboarding_done');
      if (!onboardingDone) {
        Get.offAllNamed(Routes.onboarding);
      } else {
        Get.offAllNamed(Routes.dashboard);
      }
    }
  }

  Future<void> login(String email, String password) async {
    isLoading.value = true;
    errorMessage.value = '';
    // final result = await loginUseCase(email, password);
    // result.fold(
    //   (error) => errorMessage.value = error,
    //   (user) => currentUser.value = user,
    // );
    isLoading.value = false;
  }

  Future<void> signup(String email, String password, String name) async {
    isLoading.value = true;
    errorMessage.value = '';
    // final result = await signupUseCase(email, password, name);
    // result.fold(
    //   (error) => errorMessage.value = error,
    //   (user) {
    //     currentUser.value = user;
    //     // Mark as new user for onboarding
    //     Get.find<StorageService>().setBool('onboarding_done', false);
    //   },
    // );
    isLoading.value = false;
  }

  Future<void> signInWithGoogle() async {
    isLoading.value = true;
    errorMessage.value = '';
    // final result = await googleSignInUseCase();
    // result.fold(
    //   (error) => errorMessage.value = error,
    //   (user) => currentUser.value = user,
    // );
    isLoading.value = false;
  }

  Future<void> logout() async {
    isLoading.value = true;
    // final result = await logoutUseCase();
    // result.fold(
    //   (error) => Get.snackbar('Error', error),
    //   (_) {
    //     currentUser.value = null;
    //     Get.offAllNamed(Routes.login);
    //   },
    // );
    isLoading.value = false;
  }

  bool get isAuthenticated => currentUser.value != null;
  bool get isPremium => currentUser.value?.isPremium ?? false;
}
