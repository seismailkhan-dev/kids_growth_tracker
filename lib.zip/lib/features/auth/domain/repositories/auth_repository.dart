// lib/features/auth/domain/repositories/auth_repository.dart

import 'package:dartz/dartz.dart';
import '../entities/user_entity.dart';

abstract class AuthRepository {
  Stream<UserEntity?> get authStateChanges;
  Future<Either<String, UserEntity>> login(String email, String password);
  Future<Either<String, UserEntity>> signup(String email, String password, String name);
  Future<Either<String, UserEntity>> signInWithGoogle();
  Future<Either<String, void>> logout();
  Future<Either<String, void>> sendPasswordReset(String email);
  Future<UserEntity?> getCurrentUser();
}
