// lib/features/auth/domain/usecases/signup_usecase.dart
import 'package:dartz/dartz.dart';
import '../entities/user_entity.dart';
import '../repositories/auth_repository.dart';

class SignupUseCase {
  final AuthRepository _repository;
  SignupUseCase(this._repository);

  Future<Either<String, UserEntity>> call(String email, String password, String name) =>
      _repository.signup(email, password, name);
}
