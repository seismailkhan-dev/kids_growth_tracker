// lib/features/auth/domain/usecases/google_signin_usecase.dart
import 'package:dartz/dartz.dart';
import '../entities/user_entity.dart';
import '../repositories/auth_repository.dart';

class GoogleSignInUseCase {
  final AuthRepository _repository;
  GoogleSignInUseCase(this._repository);

  Future<Either<String, UserEntity>> call() => _repository.signInWithGoogle();
}
