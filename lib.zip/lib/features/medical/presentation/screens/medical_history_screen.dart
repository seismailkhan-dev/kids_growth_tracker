// lib/features/medical/presentation/screens/medical_history_screen.dart

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import '../../../../core/constants/app_colors.dart';
import '../../../../core/widgets/app_card.dart';

class MedicalHistoryScreen extends StatefulWidget {
  const MedicalHistoryScreen({super.key});

  @override
  State<MedicalHistoryScreen> createState() => _MedicalHistoryScreenState();
}

class _MedicalHistoryScreenState extends State<MedicalHistoryScreen>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;

  final List<Map<String, dynamic>> _visits = [
    {
      'type': 'Doctor Visit',
      'doctor': 'Dr. Sarah Smith',
      'reason': 'Routine check-up',
      'date': DateTime.now().subtract(const Duration(days: 30)),
      'notes': 'All vitals normal. Recommended vitamin D supplement.',
    },
  ];

  final List<Map<String, dynamic>> _vaccines = [
    {'name': 'BCG', 'date': DateTime(2022, 1, 15), 'status': 'Done'},
    {'name': 'Hepatitis B', 'date': DateTime(2022, 2, 20), 'status': 'Done'},
    {'name': 'DPT', 'date': DateTime(2022, 4, 10), 'status': 'Done'},
    {'name': 'Polio', 'date': DateTime(2022, 6, 5), 'status': 'Done'},
    {'name': 'MMR', 'date': DateTime(2023, 1, 12), 'status': 'Due'},
  ];

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 3, vsync: this);
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Medical History'),
        bottom: TabBar(
          controller: _tabController,
          tabs: const [
            Tab(text: 'Visits'),
            Tab(text: 'Vaccines'),
            Tab(text: 'Documents'),
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _showAddVisitSheet(context),
        icon: const Icon(Icons.add),
        label: const Text('Add Record'),
        backgroundColor: AppColors.mistyRose,
        foregroundColor: AppColors.secondary,
      ),
      body: TabBarView(
        controller: _tabController,
        children: [
          _VisitsTab(visits: _visits),
          _VaccinesTab(vaccines: _vaccines),
          _DocumentsTab(),
        ],
      ),
    );
  }

  void _showAddVisitSheet(BuildContext context) {
    final doctorCtrl = TextEditingController();
    final reasonCtrl = TextEditingController();
    final notesCtrl = TextEditingController();

    Get.bottomSheet(
      Container(
        decoration: const BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
        ),
        padding: EdgeInsets.fromLTRB(
          24, 16, 24, MediaQuery.of(context).viewInsets.bottom + 24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Add Medical Visit', style: Theme.of(context).textTheme.headlineSmall),
            const SizedBox(height: 16),
            TextField(controller: doctorCtrl,
              decoration: const InputDecoration(labelText: "Doctor's Name")),
            const SizedBox(height: 12),
            TextField(controller: reasonCtrl,
              decoration: const InputDecoration(labelText: 'Reason for Visit')),
            const SizedBox(height: 12),
            TextField(controller: notesCtrl, maxLines: 3,
              decoration: const InputDecoration(
                labelText: 'Doctor\'s Notes',
                alignLabelWithHint: true,
              )),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {
                setState(() {
                  _visits.insert(0, {
                    'type': 'Doctor Visit',
                    'doctor': doctorCtrl.text,
                    'reason': reasonCtrl.text,
                    'date': DateTime.now(),
                    'notes': notesCtrl.text,
                  });
                });
                Get.back();
              },
              style: ElevatedButton.styleFrom(
                minimumSize: const Size(double.infinity, 52),
                backgroundColor: AppColors.secondary,
              ),
              child: const Text('Save Visit', style: TextStyle(color: Colors.white)),
            ),
          ],
        ),
      ),
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
    );
  }
}

class _VisitsTab extends StatelessWidget {
  final List<Map<String, dynamic>> visits;
  const _VisitsTab({required this.visits});

  @override
  Widget build(BuildContext context) {
    if (visits.isEmpty) {
      return Container();
      // return  EmptyState(
      //   title: 'No Medical Visits',
      //   message: 'Add your child\'s first medical visit',
      //   icon: Icons.local_hospital_outlined,
      // );
    }
    return ListView.builder(
      padding: const EdgeInsets.all(16),
      itemCount: visits.length,
      itemBuilder: (ctx, i) {
        final visit = visits[i];
        return AppCard(
          margin: const EdgeInsets.only(bottom: 12),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Container(
                    width: 40, height: 40,
                    decoration: BoxDecoration(
                      color: AppColors.secondary.withOpacity(0.1),
                      shape: BoxShape.circle,
                    ),
                    child: const Icon(Icons.local_hospital, color: AppColors.secondary, size: 20),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(visit['doctor'] as String,
                          style: Theme.of(ctx).textTheme.titleMedium),
                        Text(DateFormat('MMM d, yyyy').format(visit['date'] as DateTime),
                          style: Theme.of(ctx).textTheme.bodySmall),
                      ],
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                decoration: BoxDecoration(
                  color: AppColors.info.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Text(visit['reason'] as String,
                  style: const TextStyle(color: AppColors.info, fontSize: 12)),
              ),
              if ((visit['notes'] as String).isNotEmpty) ...[
                const SizedBox(height: 8),
                Text(visit['notes'] as String,
                  style: Theme.of(ctx).textTheme.bodySmall),
              ],
            ],
          ),
        );
      },
    );
  }
}

class _VaccinesTab extends StatelessWidget {
  final List<Map<String, dynamic>> vaccines;
  const _VaccinesTab({required this.vaccines});

  @override
  Widget build(BuildContext context) {
    return ListView.builder(
      padding: const EdgeInsets.all(16),
      itemCount: vaccines.length,
      itemBuilder: (ctx, i) {
        final v = vaccines[i];
        final isDone = v['status'] == 'Done';
        return AppCard(
          margin: const EdgeInsets.only(bottom: 10),
          child: Row(
            children: [
              Icon(
                isDone ? Icons.check_circle : Icons.schedule,
                color: isDone ? AppColors.success : AppColors.warning,
                size: 28,
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(v['name'] as String,
                      style: Theme.of(ctx).textTheme.titleMedium),
                    Text(DateFormat('MMM d, yyyy').format(v['date'] as DateTime),
                      style: Theme.of(ctx).textTheme.bodySmall),
                  ],
                ),
              ),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                decoration: BoxDecoration(
                  color: (isDone ? AppColors.success : AppColors.warning).withOpacity(0.1),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Text(
                  v['status'] as String,
                  style: TextStyle(
                    color: isDone ? AppColors.success : AppColors.warning,
                    fontSize: 12,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}

class _DocumentsTab extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          const Icon(Icons.upload_file, size: 64, color: AppColors.textHint),
          const SizedBox(height: 16),
          Text('Upload Medical Documents',
            style: Theme.of(context).textTheme.headlineSmall),
          const SizedBox(height: 8),
          const Text('Store prescriptions, lab reports, X-rays'),
          const SizedBox(height: 24),
          ElevatedButton.icon(
            icon: const Icon(Icons.upload),
            label: const Text('Upload Document'),
            onPressed: () {
              // file_picker integration
              Get.snackbar('Upload', 'Document upload feature - integrate file_picker');
            },
          ),
        ],
      ),
    );
  }
}
