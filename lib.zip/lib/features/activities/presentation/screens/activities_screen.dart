// lib/features/activities/presentation/screens/activities_screen.dart

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../../../core/constants/app_colors.dart';
import '../../../../core/widgets/app_card.dart';

class ActivitiesScreen extends StatefulWidget {
  const ActivitiesScreen({super.key});

  @override
  State<ActivitiesScreen> createState() => _ActivitiesScreenState();
}

class _ActivitiesScreenState extends State<ActivitiesScreen> {
  final List<Map<String, dynamic>> _activities = [
    {'name': 'Morning Walk', 'duration': 30, 'category': 'Exercise', 'icon': Icons.directions_walk, 'color': AppColors.lightGreen},
    {'name': 'Reading', 'duration': 45, 'category': 'Learning', 'icon': Icons.menu_book, 'color': AppColors.lightBlue},
    {'name': 'Outdoor Play', 'duration': 60, 'category': 'Play', 'icon': Icons.sports_soccer, 'color': AppColors.pink},
  ];

  void _showAddActivity(BuildContext context) {
    final nameCtrl = TextEditingController();
    final durationCtrl = TextEditingController();
    String category = 'Exercise';

    Get.bottomSheet(
      StatefulBuilder(
        builder: (ctx, setState) => Container(
          decoration: const BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
          ),
          padding: EdgeInsets.fromLTRB(
            24, 16, 24, MediaQuery.of(ctx).viewInsets.bottom + 24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('Add Activity', style: Theme.of(ctx).textTheme.headlineSmall),
              const SizedBox(height: 16),
              TextField(
                controller: nameCtrl,
                decoration: const InputDecoration(labelText: 'Activity Name'),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: durationCtrl,
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(
                  labelText: 'Duration (minutes)',
                  prefixIcon: Icon(Icons.timer),
                ),
              ),
              const SizedBox(height: 12),
              DropdownButtonFormField<String>(
                value: category,
                decoration: const InputDecoration(labelText: 'Category'),
                items: ['Exercise', 'Learning', 'Play', 'Creative', 'Social']
                    .map((c) => DropdownMenuItem(value: c, child: Text(c)))
                    .toList(),
                onChanged: (v) => setState(() => category = v ?? 'Exercise'),
              ),
              const SizedBox(height: 20),
              ElevatedButton(
                onPressed: () {
                  if (nameCtrl.text.isNotEmpty) {
                    this.setState(() {
                      _activities.insert(0, {
                        'name': nameCtrl.text,
                        'duration': int.tryParse(durationCtrl.text) ?? 30,
                        'category': category,
                        'icon': Icons.star,
                        'color': AppColors.gold,
                      });
                    });
                    Get.back();
                  }
                },
                style: ElevatedButton.styleFrom(
                  minimumSize: const Size(double.infinity, 52)),
                child: const Text('Add Activity'),
              ),
            ],
          ),
        ),
      ),
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Activities & Routines')),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _showAddActivity(context),
        icon: const Icon(Icons.add),
        label: const Text('Add Activity'),
        backgroundColor: AppColors.lightGreen,
        foregroundColor: Colors.white,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Daily summary
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                gradient: AppColors.greenGradient,
                borderRadius: BorderRadius.circular(16),
              ),
              child: Row(
                children: [
                  const Icon(Icons.directions_run, color: Colors.white, size: 40),
                  const SizedBox(width: 16),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text('Today\'s Activities',
                        style: TextStyle(color: Colors.white70, fontSize: 13)),
                      Text(
                        '${_activities.length} activities',
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 22,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                      Text(
                        '${_activities.fold(0, (s, a) => s + (a['duration'] as int))} minutes total',
                        style: const TextStyle(color: Colors.white70),
                      ),
                    ],
                  ),
                ],
              ),
            ),
            const SizedBox(height: 20),
            Text('Activity Log', style: Theme.of(context).textTheme.headlineSmall),
            const SizedBox(height: 12),
            Expanded(
              child: ListView.builder(
                itemCount: _activities.length,
                itemBuilder: (ctx, i) {
                  final a = _activities[i];
                  final color = a['color'] as Color;
                  return AppCard(
                    margin: const EdgeInsets.only(bottom: 12),
                    child: Row(
                      children: [
                        Container(
                          width: 48, height: 48,
                          decoration: BoxDecoration(
                            color: color.withOpacity(0.15),
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: Icon(a['icon'] as IconData, color: color),
                        ),
                        const SizedBox(width: 16),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(a['name'] as String,
                                style: Theme.of(ctx).textTheme.titleMedium),
                              Text(a['category'] as String,
                                style: Theme.of(ctx).textTheme.bodySmall),
                            ],
                          ),
                        ),
                        Text(
                          '${a['duration']} min',
                          style: TextStyle(
                            color: color,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                      ],
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
