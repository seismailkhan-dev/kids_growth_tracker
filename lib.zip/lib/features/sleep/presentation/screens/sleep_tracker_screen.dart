// lib/features/sleep/presentation/screens/sleep_tracker_screen.dart

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import '../../../../core/constants/app_colors.dart';
import '../../../../core/widgets/app_card.dart';
import '../../../../core/widgets/loading_widget.dart';
import '../controllers/sleep_controller.dart';
import '../../domain/entities/sleep_record_entity.dart';

class SleepTrackerScreen extends StatelessWidget {
  const SleepTrackerScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final controller = Get.find<SleepController>();

    return Scaffold(
      appBar: AppBar(
        title: Obx(() => Text('${controller.selectedChild.value?.name ?? ''} Sleep')),
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _showAddSleepSheet(context, controller),
        icon: const Icon(Icons.add),
        label: const Text('Log Sleep'),
        backgroundColor: AppColors.lightBlue,
        foregroundColor: Colors.white,
      ),
      body: Obx(() {
        if (controller.isLoading.value) {
          return const LoadingWidget(message: 'Loading sleep data...');
        }
        return SingleChildScrollView(
          padding: const EdgeInsets.all(16),
          child: Column(
            children: [
              // Summary card
              _SleepSummaryCard(controller: controller),
              const SizedBox(height: 16),

              // Timeline
              if (controller.records.isEmpty)
                const EmptyState(
                  title: 'No Sleep Records',
                  message: 'Log your child\'s first sleep session',
                  icon: Icons.bedtime_outlined,
                )
              else
                ...controller.records.map((r) => _SleepRecordCard(record: r)),
            ],
          ),
        );
      }),
    );
  }

  void _showAddSleepSheet(BuildContext context, SleepController controller) {
    DateTime? bedtime;
    DateTime? wakeTime;
    String quality = 'good';
    final notesCtrl = TextEditingController();

    Get.bottomSheet(
      StatefulBuilder(
        builder: (context, setState) => Container(
          decoration: const BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
          ),
          padding: EdgeInsets.fromLTRB(
            24, 16, 24, MediaQuery.of(context).viewInsets.bottom + 24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Center(
                child: Container(
                  width: 40, height: 4,
                  decoration: BoxDecoration(
                    color: Colors.grey.shade300,
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),
              ),
              const SizedBox(height: 16),
              Text('Log Sleep', style: Theme.of(context).textTheme.headlineSmall),
              const SizedBox(height: 16),

              // Bedtime picker
              _TimePicker(
                label: 'Bedtime',
                icon: Icons.nightlight,
                time: bedtime,
                onTap: () async {
                  final t = await showDateTimePicker(context);
                  if (t != null) setState(() => bedtime = t);
                },
              ),
              const SizedBox(height: 12),

              // Wake time picker
              _TimePicker(
                label: 'Wake Time',
                icon: Icons.wb_sunny,
                time: wakeTime,
                onTap: () async {
                  final t = await showDateTimePicker(context);
                  if (t != null) setState(() => wakeTime = t);
                },
              ),
              const SizedBox(height: 16),

              // Quality
              Text('Sleep Quality', style: Theme.of(context).textTheme.titleMedium),
              const SizedBox(height: 8),
              Row(
                children: ['good', 'fair', 'poor'].map((q) {
                  final colors = {
                    'good': AppColors.success,
                    'fair': AppColors.warning,
                    'poor': AppColors.error,
                  };
                  final icons = {
                    'good': Icons.sentiment_very_satisfied,
                    'fair': Icons.sentiment_neutral,
                    'poor': Icons.sentiment_dissatisfied,
                  };
                  return Expanded(
                    child: Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 4),
                      child: GestureDetector(
                        onTap: () => setState(() => quality = q),
                        child: Container(
                          padding: const EdgeInsets.symmetric(vertical: 12),
                          decoration: BoxDecoration(
                            color: quality == q
                                ? colors[q]!.withOpacity(0.15)
                                : Colors.grey.shade100,
                            borderRadius: BorderRadius.circular(12),
                            border: quality == q
                                ? Border.all(color: colors[q]!)
                                : null,
                          ),
                          child: Column(
                            children: [
                              Icon(icons[q], color: colors[q], size: 24),
                              const SizedBox(height: 4),
                              Text(q.capitalize!,
                                style: TextStyle(
                                  color: colors[q],
                                  fontSize: 12,
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  );
                }).toList(),
              ),
              const SizedBox(height: 12),

              TextField(
                controller: notesCtrl,
                decoration: const InputDecoration(
                  labelText: 'Notes (optional)',
                  prefixIcon: Icon(Icons.notes),
                ),
              ),
              const SizedBox(height: 20),

              Obx(() => ElevatedButton(
                onPressed: controller.isLoading.value ? null : () async {
                  if (bedtime == null || wakeTime == null) {
                    Get.snackbar('Error', 'Please set bedtime and wake time');
                    return;
                  }
                  await controller.addRecord(
                    startTime: bedtime!,
                    endTime: wakeTime!,
                    quality: quality,
                    notes: notesCtrl.text.isNotEmpty ? notesCtrl.text : null,
                  );
                  Get.back();
                },
                style: ElevatedButton.styleFrom(
                  minimumSize: const Size(double.infinity, 52),
                  backgroundColor: const Color(0xFF87CEFA),
                ),
                child: const Text('Save Sleep Record', style: TextStyle(color: Colors.white)),
              )),
            ],
          ),
        ),
      ),
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
    );
  }

  Future<DateTime?> showDateTimePicker(BuildContext context) async {
    final date = await showDatePicker(
      context: context,
      initialDate: DateTime.now(),
      firstDate: DateTime.now().subtract(const Duration(days: 30)),
      lastDate: DateTime.now(),
    );
    if (date == null) return null;
    final time = await showTimePicker(
      context: context,
      initialTime: TimeOfDay.now(),
    );
    if (time == null) return null;
    return DateTime(date.year, date.month, date.day, time.hour, time.minute);
  }
}

class _SleepSummaryCard extends StatelessWidget {
  final SleepController controller;
  const _SleepSummaryCard({required this.controller});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [Color(0xFF87CEFA), Color(0xFF6C63FF)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Row(
        children: [
          const Icon(Icons.bedtime, color: Colors.white, size: 48),
          const SizedBox(width: 16),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text('Avg. Sleep (last 7 days)',
                style: TextStyle(color: Colors.white70, fontSize: 13)),
              Text(
                '${controller.averageSleepHours.toStringAsFixed(1)} hrs',
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 28,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _SleepRecordCard extends StatelessWidget {
  final SleepRecordEntity record;
  const _SleepRecordCard({required this.record});

  @override
  Widget build(BuildContext context) {
    final qualityColors = {
      'good': AppColors.success,
      'fair': AppColors.warning,
      'poor': AppColors.error,
    };
    final color = qualityColors[record.quality] ?? AppColors.success;

    return AppCard(
      margin: const EdgeInsets.only(bottom: 12),
      child: Row(
        children: [
          Container(
            width: 48, height: 48,
            decoration: BoxDecoration(
              color: color.withOpacity(0.1),
              shape: BoxShape.circle,
            ),
            child: Icon(Icons.bedtime, color: color),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  DateFormat('EEE, MMM d').format(record.startTime),
                  style: Theme.of(context).textTheme.titleMedium,
                ),
                const SizedBox(height: 4),
                Text(
                  '${DateFormat('h:mm a').format(record.startTime)} → ${DateFormat('h:mm a').format(record.endTime)}',
                  style: Theme.of(context).textTheme.bodySmall,
                ),
              ],
            ),
          ),
          Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Text(
                '${record.durationHours.toStringAsFixed(1)} hrs',
                style: TextStyle(
                  color: color,
                  fontWeight: FontWeight.w700,
                  fontSize: 16,
                ),
              ),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                decoration: BoxDecoration(
                  color: color.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Text(
                  record.quality.capitalize!,
                  style: TextStyle(color: color, fontSize: 11),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _TimePicker extends StatelessWidget {
  final String label;
  final IconData icon;
  final DateTime? time;
  final VoidCallback onTap;

  const _TimePicker({
    required this.label,
    required this.icon,
    this.time,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
        decoration: BoxDecoration(
          border: Border.all(color: Colors.grey.shade300),
          borderRadius: BorderRadius.circular(12),
          color: Colors.grey.shade50,
        ),
        child: Row(
          children: [
            Icon(icon, color: Colors.grey),
            const SizedBox(width: 12),
            Text(
              time != null
                  ? DateFormat('EEE, MMM d • h:mm a').format(time!)
                  : label,
              style: TextStyle(
                color: time != null ? Colors.black87 : Colors.grey,
              ),
            ),
            const Spacer(),
            const Icon(Icons.chevron_right, color: Colors.grey),
          ],
        ),
      ),
    );
  }
}
