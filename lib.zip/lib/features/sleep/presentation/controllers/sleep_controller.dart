// lib/features/sleep/presentation/controllers/sleep_controller.dart
import 'package:get/get.dart';
import 'package:uuid/uuid.dart';
import '../../domain/entities/sleep_record_entity.dart';
import '../../domain/usecases/get_sleep_records_usecase.dart';
import '../../domain/usecases/add_sleep_record_usecase.dart';
import '../../../child/domain/entities/child_entity.dart';

class SleepController extends GetxController {
  final GetSleepRecordsUseCase getSleepRecords;
  final AddSleepRecordUseCase addSleepRecord;

  SleepController({required this.getSleepRecords, required this.addSleepRecord});

  final RxList<SleepRecordEntity> records = <SleepRecordEntity>[].obs;
  final RxBool isLoading = false.obs;
  Rx<ChildEntity?> selectedChild = Rx<ChildEntity?>(null);

  @override
  void onInit() {
    super.onInit();
    final child = Get.arguments as ChildEntity?;
    if (child != null) {
      selectedChild.value = child;
      loadRecords(child.id);
    }
  }

  Future<void> loadRecords(String childId) async {
    isLoading.value = true;
    final result = await getSleepRecords(childId);
    result.fold(
      (e) => Get.snackbar('Error', e),
      (list) => records.assignAll(list),
    );
    isLoading.value = false;
  }

  Future<void> addRecord({
    required DateTime startTime,
    required DateTime endTime,
    String quality = 'good',
    String? notes,
  }) async {
    final child = selectedChild.value;
    if (child == null) return;

    final record = SleepRecordEntity(
      id: const Uuid().v4(),
      childId: child.id,
      startTime: startTime,
      endTime: endTime,
      quality: quality,
      notes: notes,
    );

    isLoading.value = true;
    final result = await addSleepRecord(record);
    result.fold(
      (e) => Get.snackbar('Error', e),
      (r) => records.insert(0, r),
    );
    isLoading.value = false;
  }

  double get averageSleepHours {
    if (records.isEmpty) return 0;
    final total = records.take(7).fold(0.0, (sum, r) => sum + r.durationHours);
    return total / records.take(7).length;
  }
}
