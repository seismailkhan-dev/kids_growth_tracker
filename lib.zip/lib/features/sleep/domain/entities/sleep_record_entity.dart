// lib/features/sleep/domain/entities/sleep_record_entity.dart

class SleepRecordEntity {
  final String id;
  final String childId;
  final DateTime startTime;
  final DateTime endTime;
  final String quality; // good, fair, poor
  final String? notes;

  const SleepRecordEntity({
    required this.id,
    required this.childId,
    required this.startTime,
    required this.endTime,
    this.quality = 'good',
    this.notes,
  });

  Duration get duration => endTime.difference(startTime);
  double get durationHours => duration.inMinutes / 60;

  Map<String, dynamic> toMap() => {
    'id': id,
    'childId': childId,
    'startTime': startTime.toIso8601String(),
    'endTime': endTime.toIso8601String(),
    'quality': quality,
    'notes': notes,
  };

  factory SleepRecordEntity.fromMap(Map<String, dynamic> map) => SleepRecordEntity(
    id: map['id'] ?? '',
    childId: map['childId'] ?? '',
    startTime: DateTime.parse(map['startTime']),
    endTime: DateTime.parse(map['endTime']),
    quality: map['quality'] ?? 'good',
    notes: map['notes'],
  );
}
