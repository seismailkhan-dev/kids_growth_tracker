// lib/features/sleep/domain/repositories/sleep_repository.dart
import 'package:dartz/dartz.dart';
import '../entities/sleep_record_entity.dart';

abstract class SleepRepository {
  Future<Either<String, List<SleepRecordEntity>>> getSleepRecords(String childId);
  Future<Either<String, SleepRecordEntity>> addSleepRecord(SleepRecordEntity record);
  Future<Either<String, void>> deleteSleepRecord(String recordId);
}
