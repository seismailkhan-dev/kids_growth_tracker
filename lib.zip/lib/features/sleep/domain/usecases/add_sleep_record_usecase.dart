// lib/features/sleep/domain/usecases/add_sleep_record_usecase.dart
import 'package:dartz/dartz.dart';
import '../entities/sleep_record_entity.dart';
import '../repositories/sleep_repository.dart';

class AddSleepRecordUseCase {
  final SleepRepository _repo;
  AddSleepRecordUseCase(this._repo);
  Future<Either<String, SleepRecordEntity>> call(SleepRecordEntity record) =>
      _repo.addSleepRecord(record);
}
