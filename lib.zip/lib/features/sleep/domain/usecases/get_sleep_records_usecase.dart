// lib/features/sleep/domain/usecases/get_sleep_records_usecase.dart
import 'package:dartz/dartz.dart';
import '../entities/sleep_record_entity.dart';
import '../repositories/sleep_repository.dart';

class GetSleepRecordsUseCase {
  final SleepRepository _repo;
  GetSleepRecordsUseCase(this._repo);
  Future<Either<String, List<SleepRecordEntity>>> call(String childId) =>
      _repo.getSleepRecords(childId);
}

