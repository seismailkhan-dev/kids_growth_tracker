// lib/features/sleep/data/repositories/sleep_repository_impl.dart
import 'package:dartz/dartz.dart';
import '../../domain/entities/sleep_record_entity.dart';
import '../../domain/repositories/sleep_repository.dart';
import '../datasources/sleep_remote_datasource.dart';

class SleepRepositoryImpl implements SleepRepository {
  final SleepRemoteDataSource _ds;
  SleepRepositoryImpl(this._ds);

  @override
  Future<Either<String, List<SleepRecordEntity>>> getSleepRecords(String childId) async {
    try { return Right(await _ds.getSleepRecords(childId)); }
    catch (e) { return Left(e.toString()); }
  }

  @override
  Future<Either<String, SleepRecordEntity>> addSleepRecord(SleepRecordEntity record) async {
    try { return Right(await _ds.addSleepRecord(record)); }
    catch (e) { return Left(e.toString()); }
  }

  @override
  Future<Either<String, void>> deleteSleepRecord(String recordId) async {
    try { await _ds.deleteSleepRecord(recordId); return const Right(null); }
    catch (e) { return Left(e.toString()); }
  }
}
