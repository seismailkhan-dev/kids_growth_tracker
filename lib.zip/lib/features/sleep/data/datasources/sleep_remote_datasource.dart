// lib/features/sleep/data/datasources/sleep_remote_datasource.dart
import 'package:cloud_firestore/cloud_firestore.dart';
import '../../domain/entities/sleep_record_entity.dart';

abstract class SleepRemoteDataSource {
  Future<List<SleepRecordEntity>> getSleepRecords(String childId);
  Future<SleepRecordEntity> addSleepRecord(SleepRecordEntity record);
  Future<void> deleteSleepRecord(String recordId);
}

class SleepRemoteDataSourceImpl implements SleepRemoteDataSource {
  final FirebaseFirestore _db = FirebaseFirestore.instance;

  @override
  Future<List<SleepRecordEntity>> getSleepRecords(String childId) async {
    final snap = await _db.collection('sleep_records')
        .where('childId', isEqualTo: childId)
        .orderBy('startTime', descending: true)
        .get();
    return snap.docs.map((d) => SleepRecordEntity.fromMap(d.data())).toList();
  }

  @override
  Future<SleepRecordEntity> addSleepRecord(SleepRecordEntity record) async {
    final docRef = _db.collection('sleep_records').doc();
    final updated = SleepRecordEntity(
      id: docRef.id,
      childId: record.childId,
      startTime: record.startTime,
      endTime: record.endTime,
      quality: record.quality,
      notes: record.notes,
    );
    await docRef.set(updated.toMap());
    return updated;
  }

  @override
  Future<void> deleteSleepRecord(String recordId) async {
    await _db.collection('sleep_records').doc(recordId).delete();
  }
}
