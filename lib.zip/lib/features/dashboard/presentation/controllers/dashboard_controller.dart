// lib/features/dashboard/presentation/controllers/dashboard_controller.dart

import 'package:get/get.dart';
import '../../../child/domain/usecases/get_children_usecase.dart';
import '../../../child/domain/entities/child_entity.dart';
import '../../../auth/presentation/controllers/auth_controller.dart';
import '../../../../core/services/ad_service.dart';

class DashboardController extends GetxController {


  final RxList<ChildEntity> children = <ChildEntity>[].obs;
  final RxBool isLoading = false.obs;
  final RxInt selectedTabIndex = 0.obs;

  @override
  void onInit() {
    super.onInit();
    loadData();
    // Load ads for free users
    final auth = Get.find<AuthController>();
    if (!auth.isPremium) {
      Get.find<AdService>().loadBannerAd();
    }
  }

  Future<void> loadData() async {
    isLoading.value = true;
    final auth = Get.find<AuthController>();
    final userId = auth.currentUser.value?.uid;
    if (userId == null) {
      isLoading.value = false;
      return;
    }
    // final result = await getChildrenUseCase(userId);
    // result.fold(
    //   (error) {},
    //   (list) => children.assignAll(list),
    // );
    isLoading.value = false;
  }

  void setTab(int index) => selectedTabIndex.value = index;
}
