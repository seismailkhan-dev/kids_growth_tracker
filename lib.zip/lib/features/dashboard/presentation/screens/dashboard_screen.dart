// lib/features/dashboard/presentation/screens/dashboard_screen.dart

import 'package:family_health_tracker/features/child/domain/repositories/child_repository.dart';
import 'package:family_health_tracker/features/child/domain/usecases/get_children_usecase.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../../../core/constants/app_colors.dart';
import '../../../../core/routes/app_pages.dart';
import '../../../../core/widgets/child_card.dart';
import '../../../../core/widgets/app_card.dart';
import '../../../../core/widgets/loading_widget.dart';
import '../../../auth/presentation/controllers/auth_controller.dart';
import '../../../subscription/presentation/controllers/subscription_controller.dart';
import '../controllers/dashboard_controller.dart';

// lib/features/dashboard/presentation/screens/dashboard_screen.dart

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../../../core/constants/app_colors.dart';
import '../../../../core/routes/app_pages.dart';
import '../../../../core/widgets/child_card.dart';
import '../../../../core/widgets/app_card.dart';
import '../../../../core/widgets/loading_widget.dart';
import '../../../auth/presentation/controllers/auth_controller.dart';
import '../../../subscription/presentation/controllers/subscription_controller.dart';
import '../controllers/dashboard_controller.dart';

class DashboardScreen extends StatefulWidget {
  const DashboardScreen({super.key});

  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {

  final DashboardController controller = Get.put(DashboardController());
  @override
  Widget build(BuildContext context) {


    return Scaffold(
      body: SafeArea(
        child: RefreshIndicator(
          onRefresh: controller.loadData,
          color: AppColors.primary,
          child: CustomScrollView(
            slivers: [
              // App Bar Section
              SliverToBoxAdapter(
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(20, 20, 20, 0),
                  child: Row(
                    children: [
                      Obx(() {
                        print(controller.isLoading.value);
                        // final user = authController?.currentUser.value;
                        return Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              'Hello,  Parent} 👋',
                              style: Theme.of(context).textTheme.headlineSmall,
                            ),
                            Text(
                              'How\'s the family today?',
                              style: Theme.of(context).textTheme.bodyMedium,
                            ),
                          ],
                        );
                      }),
                      const Spacer(),
                      IconButton(
                        icon: const Icon(Icons.notifications_outlined),
                        onPressed: () => Get.toNamed(Routes.notifications),
                      ),
                      GestureDetector(
                        onTap: () => Get.toNamed(Routes.settings),
                        child: Obx(() {
                          print(controller.isLoading.value);

                          // final user = authController?.currentUser.value;
                          return CircleAvatar(
                            radius: 20,
                            backgroundColor: AppColors.primary.withOpacity(0.1),
                            backgroundImage:
                            // user?.photoUrl != null
                            //     ? NetworkImage(user!.photoUrl!):
                            null,
                            child:
                            // user?.photoUrl == null ?
                            Text(
                              // user?.displayName?.substring(0, 1).toUpperCase() ??
                                  'P',
                              style: const TextStyle(
                                color: AppColors.primary,
                                fontWeight: FontWeight.w700,
                              ),
                            )
                                // : null,
                          );
                        }),
                      ),
                    ],
                  ),
                ),
              ),

              // // Premium Banner
              // Obx(() {
              //   // if (!subController.isPremium.value) {
              //     return  SliverToBoxAdapter(
              //       child: Padding(
              //         padding: EdgeInsets.fromLTRB(20, 16, 20, 0),
              //         child: _PremiumBanner(),
              //       ),
              //     );
              //   // }
              //   return const SliverToBoxAdapter(child: SizedBox.shrink());
              // }),

              // Children Header
              SliverToBoxAdapter(
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(20, 24, 20, 12),
                  child: Row(
                    children: [
                      Text(
                        'Your Children',
                        style: Theme.of(context).textTheme.headlineSmall,
                      ),
                      const Spacer(),
                      TextButton.icon(
                        icon: const Icon(Icons.add, size: 18),
                        label: const Text('Add'),
                        onPressed: () => Get.toNamed(Routes.addChild),
                      ),
                    ],
                  ),
                ),
              ),

              // Children List
              Obx(() {
                if (controller.isLoading.value) {
                  return const SliverToBoxAdapter(child: ShimmerCard());
                }
                if (controller.children.isEmpty) {
                  return  SliverToBoxAdapter(
                    child: Padding(
                      padding: EdgeInsets.symmetric(horizontal: 20),
                      child: _NoChildrenCard(),
                    ),
                  );
                }
                return SliverToBoxAdapter(
                  child: SizedBox(
                    height: 200,
                    child: ListView.builder(
                      scrollDirection: Axis.horizontal,
                      padding: const EdgeInsets.symmetric(horizontal: 20),
                      itemCount: controller.children.length,
                      itemBuilder: (context, i) {
                        final child = controller.children[i];
                        return ChildCard(
                          child: child,
                          onTap: () => Get.toNamed(Routes.childProfile, arguments: child),
                        );
                      },
                    ),
                  ),
                );
              }),

              // Quick Actions Header
              SliverToBoxAdapter(
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(20, 24, 20, 12),
                  child: Text(
                    'Quick Actions',
                    style: Theme.of(context).textTheme.headlineSmall,
                  ),
                ),
              ),

              // Quick Actions Grid
              SliverPadding(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                sliver: SliverGrid(
                  delegate: SliverChildListDelegate([
                    _QuickActionCard(
                      title: 'Growth',
                      icon: Icons.show_chart,
                      color: AppColors.pink,
                      onTap: () => Get.toNamed(Routes.growthTracker),
                    ),
                    _QuickActionCard(
                      title: 'Sleep',
                      icon: Icons.bedtime_outlined,
                      color: AppColors.lightBlue,
                      onTap: () => Get.toNamed(Routes.sleepTracker),
                    ),
                    _QuickActionCard(
                      title: 'Activities',
                      icon: Icons.directions_run,
                      color: AppColors.lightGreen,
                      onTap: () => Get.toNamed(Routes.activities),
                    ),
                    _QuickActionCard(
                      title: 'Medical',
                      icon: Icons.medical_services_outlined,
                      color: AppColors.mistyRose,
                      onTap: () => Get.toNamed(Routes.medicalHistory),
                    ),
                    _QuickActionCard(
                      title: 'AI Insights',
                      icon: Icons.auto_awesome,
                      color: AppColors.gold,
                      onTap: () => Get.toNamed(Routes.aiInsights),
                      isPremium: true,
                    ),
                    _QuickActionCard(
                      title: 'Reports',
                      icon: Icons.picture_as_pdf_outlined,
                      color: AppColors.primary,
                      onTap: () => Get.toNamed(Routes.reports),
                      isPremium: true,
                    ),
                  ]),
                  gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 3,
                    crossAxisSpacing: 12,
                    mainAxisSpacing: 12,
                    childAspectRatio: 1,
                  ),
                ),
              ),

              const SliverToBoxAdapter(child: SizedBox(height: 32)),
            ],
          ),
        ),
      ),
    );
  }
}

// Premium Banner, No Children Card, Quick Action Card remain unchanged

class _PremiumBanner extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => Get.toNamed(Routes.subscription),
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          gradient: AppColors.primaryGradient,
          borderRadius: BorderRadius.circular(16),
        ),
        child: Row(
          children: [
            const Icon(Icons.star, color: Colors.amber, size: 28),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'Upgrade to Premium',
                    style: TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.w700,
                      fontSize: 14,
                    ),
                  ),
                  Text(
                    'Unlock AI insights, unlimited children & more',
                    style: TextStyle(
                      color: Colors.white.withOpacity(0.85),
                      fontSize: 12,
                    ),
                  ),
                ],
              ),
            ),
            const Icon(Icons.arrow_forward_ios, color: Colors.white70, size: 16),
          ],
        ),
      ),
    );
  }
}

class _NoChildrenCard extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return AppCard(
      child: Column(
        children: [
          const Icon(Icons.child_care, size: 48, color: AppColors.primary),
          const SizedBox(height: 12),
          Text(
            'No children added yet',
            style: Theme.of(context).textTheme.titleLarge,
          ),
          const SizedBox(height: 8),
          Text(
            'Add your first child to start tracking their health',
            style: Theme.of(context).textTheme.bodyMedium,
            textAlign: TextAlign.center,
          ),
          const SizedBox(height: 16),
          ElevatedButton.icon(
            icon: const Icon(Icons.add),
            label: const Text('Add Child'),
            onPressed: () => Get.toNamed(Routes.addChild),
          ),
        ],
      ),
    );
  }
}

class _QuickActionCard extends StatelessWidget {
  final String title;
  final IconData icon;
  final Color color;
  final VoidCallback onTap;
  final bool isPremium;

  const _QuickActionCard({
    required this.title,
    required this.icon,
    required this.color,
    required this.onTap,
    this.isPremium = false,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        decoration: BoxDecoration(
          color: color.withOpacity(0.15),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: color.withOpacity(0.2)),
        ),
        child: Stack(
          children: [
            Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(icon, color: color, size: 32),
                const SizedBox(height: 8),
                Text(
                  title,
                  style: TextStyle(
                    color: color,
                    fontSize: 12,
                    fontWeight: FontWeight.w600,
                  ),
                  textAlign: TextAlign.center,
                ),
              ],
            ),
            if (isPremium)
              Positioned(
                top: 4,
                right: 4,
                child: Container(
                  padding: const EdgeInsets.all(2),
                  decoration: const BoxDecoration(
                    color: Colors.amber,
                    shape: BoxShape.circle,
                  ),
                  child: const Icon(Icons.star, size: 10, color: Colors.white),
                ),
              ),
          ],
        ),
      ),
    );
  }
}
