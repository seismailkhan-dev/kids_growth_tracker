// lib/features/notifications/presentation/screens/notifications_screen.dart

import 'package:flutter/material.dart';
import '../../../../core/constants/app_colors.dart';
import '../../../../core/widgets/loading_widget.dart';

class NotificationsScreen extends StatelessWidget {
  const NotificationsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final notifications = [
      _NotifData(
        title: 'Growth milestone!',
        body: 'Emma grew 2cm this month. She\'s tracking well!',
        time: '2 hours ago',
        icon: Icons.show_chart,
        color: AppColors.primary,
        isRead: false,
      ),
      _NotifData(
        title: 'Vaccine reminder',
        body: 'MMR vaccine is due next week for Liam',
        time: '1 day ago',
        icon: Icons.vaccines,
        color: AppColors.warning,
        isRead: false,
      ),
      _NotifData(
        title: 'Sleep insight',
        body: 'Emma slept 10 hours last night. Great progress!',
        time: '2 days ago',
        icon: Icons.bedtime,
        color: AppColors.lightBlue,
        isRead: true,
      ),
    ];

    return Scaffold(
      appBar: AppBar(
        title: const Text('Notifications'),
        actions: [
          TextButton(
            onPressed: () {},
            child: const Text('Mark all read'),
          ),
        ],
      ),
      body: notifications.isEmpty
          ? const EmptyState(
              title: 'No Notifications',
              message: 'You\'re all caught up!',
              icon: Icons.notifications_outlined,
            )
          : ListView.builder(
              padding: const EdgeInsets.all(16),
              itemCount: notifications.length,
              itemBuilder: (ctx, i) {
                final n = notifications[i];
                return Container(
                  margin: const EdgeInsets.only(bottom: 12),
                  decoration: BoxDecoration(
                    color: n.isRead
                        ? Theme.of(ctx).cardTheme.color
                        : n.color.withOpacity(0.05),
                    borderRadius: BorderRadius.circular(16),
                    border: n.isRead
                        ? null
                        : Border.all(color: n.color.withOpacity(0.2)),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.grey.withOpacity(0.06),
                        blurRadius: 8,
                        offset: const Offset(0, 2),
                      ),
                    ],
                  ),
                  child: ListTile(
                    contentPadding: const EdgeInsets.all(16),
                    leading: Container(
                      width: 44,
                      height: 44,
                      decoration: BoxDecoration(
                        color: n.color.withOpacity(0.1),
                        shape: BoxShape.circle,
                      ),
                      child: Icon(n.icon, color: n.color, size: 22),
                    ),
                    title: Text(
                      n.title,
                      style: TextStyle(
                        fontWeight: n.isRead ? FontWeight.w500 : FontWeight.w700,
                      ),
                    ),
                    subtitle: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const SizedBox(height: 4),
                        Text(n.body),
                        const SizedBox(height: 4),
                        Text(
                          n.time,
                          style: const TextStyle(
                            fontSize: 11,
                            color: AppColors.textHint,
                          ),
                        ),
                      ],
                    ),
                    trailing: !n.isRead
                        ? Container(
                            width: 8,
                            height: 8,
                            decoration: BoxDecoration(
                              color: n.color,
                              shape: BoxShape.circle,
                            ),
                          )
                        : null,
                  ),
                );
              },
            ),
    );
  }
}

class _NotifData {
  final String title;
  final String body;
  final String time;
  final IconData icon;
  final Color color;
  final bool isRead;

  _NotifData({
    required this.title,
    required this.body,
    required this.time,
    required this.icon,
    required this.color,
    required this.isRead,
  });
}
