// lib/features/subscription/data/repositories/subscription_repository_impl.dart
import 'package:dartz/dartz.dart';
import '../../domain/entities/subscription_entity.dart';
import '../../domain/repositories/subscription_repository.dart';
import '../datasources/subscription_datasource.dart';

class SubscriptionRepositoryImpl implements SubscriptionRepository {
  final SubscriptionDataSource _ds;
  SubscriptionRepositoryImpl(this._ds);

  @override
  Future<Either<String, SubscriptionEntity>> getSubscriptionStatus(String userId) async {
    try { return Right(await _ds.getSubscriptionStatus(userId)); }
    catch (e) { return Left(e.toString()); }
  }

  @override
  Future<Either<String, SubscriptionEntity>> purchaseSubscription(String productId) async {
    try { return Right(await _ds.purchaseSubscription(productId)); }
    catch (e) { return Left(e.toString()); }
  }

  @override
  Future<Either<String, void>> restorePurchases() async {
    try { return const Right(null); }
    catch (e) { return Left(e.toString()); }
  }
}
