// lib/features/subscription/data/datasources/subscription_datasource.dart

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:in_app_purchase/in_app_purchase.dart';
import '../../domain/entities/subscription_entity.dart';

abstract class SubscriptionDataSource {
  Future<SubscriptionEntity> getSubscriptionStatus(String userId);
  Future<SubscriptionEntity> purchaseSubscription(String productId);
}

class SubscriptionDataSourceImpl implements SubscriptionDataSource {
  final FirebaseFirestore _db = FirebaseFirestore.instance;
  final InAppPurchase _iap = InAppPurchase.instance;

  @override
  Future<SubscriptionEntity> getSubscriptionStatus(String userId) async {
    try {
      final doc = await _db.collection('users').doc(userId).get();
      if (doc.exists) {
        final data = doc.data()!;
        final expiryStr = data['subscriptionExpiry'] as String?;
        return SubscriptionEntity(
          isPremium: data['isPremium'] ?? false,
          plan: data['subscriptionPlan'],
          expiryDate: expiryStr != null ? DateTime.parse(expiryStr) : null,
        );
      }
    } catch (_) {}
    return const SubscriptionEntity(isPremium: false);
  }

  @override
  Future<SubscriptionEntity> purchaseSubscription(String productId) async {
    // In a real app, this kicks off the IAP flow
    // The purchase result is handled via InAppPurchase.instance.purchaseStream
    final available = await _iap.isAvailable();
    if (!available) throw Exception('Store not available');

    final Set<String> ids = {productId};
    final response = await _iap.queryProductDetails(ids);
    if (response.productDetails.isEmpty) {
      throw Exception('Product not found');
    }

    final purchaseParam = PurchaseParam(
      productDetails: response.productDetails.first,
    );
    await _iap.buyNonConsumable(purchaseParam: purchaseParam);

    // Return optimistic entity - actual confirmation comes via purchaseStream
    return SubscriptionEntity(
      isPremium: true,
      plan: productId.contains('monthly') ? 'monthly' : 'yearly',
      expiryDate: productId.contains('monthly')
          ? DateTime.now().add(const Duration(days: 30))
          : DateTime.now().add(const Duration(days: 365)),
    );
  }

  /// Call this when a purchase is verified to update Firestore
  Future<void> confirmPurchaseInFirestore(
      String userId, String productId, String transactionId) async {
    await _db.collection('users').doc(userId).update({
      'isPremium': true,
      'subscriptionPlan': productId.contains('monthly') ? 'monthly' : 'yearly',
      'subscriptionExpiry': productId.contains('monthly')
          ? DateTime.now().add(const Duration(days: 30)).toIso8601String()
          : DateTime.now().add(const Duration(days: 365)).toIso8601String(),
      'lastTransactionId': transactionId,
    });
  }
}
