// lib/features/subscription/presentation/controllers/subscription_controller.dart

import 'package:get/get.dart';
import '../../domain/usecases/get_subscription_status_usecase.dart';
import '../../domain/usecases/purchase_subscription_usecase.dart';
import '../../../auth/presentation/controllers/auth_controller.dart';
import '../../../../core/constants/app_constants.dart';

class SubscriptionController extends GetxController {
  final GetSubscriptionStatusUseCase getStatus;
  final PurchaseSubscriptionUseCase purchaseSubscription;

  SubscriptionController({
    required this.getStatus,
    required this.purchaseSubscription,
  });

  final RxBool isPremium = false.obs;
  final RxBool isLoading = false.obs;
  final RxString selectedPlan = 'yearly'.obs;

  @override
  void onInit() {
    super.onInit();
    checkSubscription();
  }

  Future<void> checkSubscription() async {
    final auth = Get.find<AuthController>();
    final userId = auth.currentUser.value?.uid;
    if (userId == null) return;

    final result = await getStatus(userId);
    result.fold(
      (_) {},
      (sub) => isPremium.value = sub.isActive,
    );
  }

  Future<void> purchase(String plan) async {
    isLoading.value = true;
    final productId = plan == 'monthly'
        ? AppConstants.monthlySubId
        : AppConstants.yearlySubId;

    final result = await purchaseSubscription(productId);
    result.fold(
      (error) => Get.snackbar('Purchase Failed', error),
      (sub) {
        isPremium.value = sub.isActive;
        Get.snackbar('Success', 'Welcome to Premium!');
        Get.back();
      },
    );
    isLoading.value = false;
  }

  // Feature gate helper
  bool canAccessFeature(String feature) {
    if (isPremium.value) return true;
    // Free features
    return ['growth', 'sleep', 'activities'].contains(feature);
  }
}
