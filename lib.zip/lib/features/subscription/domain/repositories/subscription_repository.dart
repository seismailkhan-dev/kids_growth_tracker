// lib/features/subscription/domain/repositories/subscription_repository.dart
import 'package:dartz/dartz.dart';
import '../entities/subscription_entity.dart';

abstract class SubscriptionRepository {
  Future<Either<String, SubscriptionEntity>> getSubscriptionStatus(String userId);
  Future<Either<String, SubscriptionEntity>> purchaseSubscription(String productId);
  Future<Either<String, void>> restorePurchases();
}
