// lib/features/subscription/domain/entities/subscription_entity.dart

class SubscriptionEntity {
  final bool isPremium;
  final String? plan; // monthly, yearly
  final DateTime? expiryDate;
  final String? transactionId;

  const SubscriptionEntity({
    this.isPremium = false,
    this.plan,
    this.expiryDate,
    this.transactionId,
  });

  bool get isActive => isPremium && (expiryDate == null || expiryDate!.isAfter(DateTime.now()));

  Map<String, dynamic> toMap() => {
    'isPremium': isPremium,
    'plan': plan,
    'expiryDate': expiryDate?.toIso8601String(),
    'transactionId': transactionId,
  };
}
