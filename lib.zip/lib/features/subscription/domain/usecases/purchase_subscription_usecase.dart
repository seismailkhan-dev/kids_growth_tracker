// lib/features/subscription/domain/usecases/purchase_subscription_usecase.dart
import 'package:dartz/dartz.dart';
import '../entities/subscription_entity.dart';
import '../repositories/subscription_repository.dart';

class PurchaseSubscriptionUseCase {
  final SubscriptionRepository _repo;
  PurchaseSubscriptionUseCase(this._repo);
  Future<Either<String, SubscriptionEntity>> call(String productId) =>
      _repo.purchaseSubscription(productId);
}
