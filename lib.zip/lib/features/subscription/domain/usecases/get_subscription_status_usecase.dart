// lib/features/subscription/domain/usecases/get_subscription_status_usecase.dart
import 'package:dartz/dartz.dart';
import '../entities/subscription_entity.dart';
import '../repositories/subscription_repository.dart';

class GetSubscriptionStatusUseCase {
  final SubscriptionRepository _repo;
  GetSubscriptionStatusUseCase(this._repo);
  Future<Either<String, SubscriptionEntity>> call(String userId) =>
      _repo.getSubscriptionStatus(userId);
}

