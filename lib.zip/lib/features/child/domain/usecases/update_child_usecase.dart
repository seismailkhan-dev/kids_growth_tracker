// lib/features/child/domain/usecases/update_child_usecase.dart
import 'package:dartz/dartz.dart';
import '../entities/child_entity.dart';
import '../repositories/child_repository.dart';

class UpdateChildUseCase {
  final ChildRepository _repo;
  UpdateChildUseCase(this._repo);
  Future<Either<String, ChildEntity>> call(ChildEntity child) =>
      _repo.updateChild(child);
}
