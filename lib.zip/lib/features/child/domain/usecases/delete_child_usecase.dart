// lib/features/child/domain/usecases/delete_child_usecase.dart
import 'package:dartz/dartz.dart';
import '../repositories/child_repository.dart';

class DeleteChildUseCase {
  final ChildRepository _repo;
  DeleteChildUseCase(this._repo);
  Future<Either<String, void>> call(String childId) =>
      _repo.deleteChild(childId);
}
