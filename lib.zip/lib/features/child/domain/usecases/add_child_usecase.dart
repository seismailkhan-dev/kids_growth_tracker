// lib/features/child/domain/usecases/add_child_usecase.dart
import 'package:dartz/dartz.dart';
import '../entities/child_entity.dart';
import '../repositories/child_repository.dart';

class AddChildUseCase {
  final ChildRepository _repo;
  AddChildUseCase(this._repo);
  Future<Either<String, ChildEntity>> call(ChildEntity child) =>
      _repo.addChild(child);
}

