// lib/features/child/domain/usecases/get_children_usecase.dart
import 'package:dartz/dartz.dart';
import '../entities/child_entity.dart';
import '../repositories/child_repository.dart';

class GetChildrenUseCase {
  final ChildRepository _repo;
  GetChildrenUseCase(this._repo);
  Future<Either<String, List<ChildEntity>>> call(String userId) =>
      _repo.getChildren(userId);
}
