// lib/features/child/domain/entities/child_entity.dart

import 'package:equatable/equatable.dart';

class ChildEntity extends Equatable {
  final String id;
  final String name;
  final DateTime dateOfBirth;
  final String gender;
  final String? bloodGroup;
  final String? photoUrl;
  final String? allergies;
  final String? notes;
  final String userId;

  const ChildEntity({
    required this.id,
    required this.name,
    required this.dateOfBirth,
    required this.gender,
    this.bloodGroup,
    this.photoUrl,
    this.allergies,
    this.notes,
    required this.userId,
  });

  @override
  List<Object?> get props => [id, name, dateOfBirth, gender, userId];

  Map<String, dynamic> toMap() => {
        'id': id,
        'name': name,
        'dateOfBirth': dateOfBirth.toIso8601String(),
        'gender': gender,
        'bloodGroup': bloodGroup,
        'photoUrl': photoUrl,
        'allergies': allergies,
        'notes': notes,
        'userId': userId,
      };

  factory ChildEntity.fromMap(Map<String, dynamic> map) => ChildEntity(
        id: map['id'] ?? '',
        name: map['name'] ?? '',
        dateOfBirth: DateTime.parse(map['dateOfBirth']),
        gender: map['gender'] ?? 'Unknown',
        bloodGroup: map['bloodGroup'],
        photoUrl: map['photoUrl'],
        allergies: map['allergies'],
        notes: map['notes'],
        userId: map['userId'] ?? '',
      );
}
