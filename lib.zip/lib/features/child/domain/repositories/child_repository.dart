// lib/features/child/domain/repositories/child_repository.dart
import 'package:dartz/dartz.dart';
import '../../data/datasources/child_remote_datasource.dart';
import '../entities/child_entity.dart';

abstract class ChildRepository {
  Future<Either<String, List<ChildEntity>>> getChildren(String userId);
  Future<Either<String, ChildEntity>> addChild(ChildEntity child);
  Future<Either<String, ChildEntity>> updateChild(ChildEntity child);
  Future<Either<String, void>> deleteChild(String childId);
}


class ChildRepositoryImpl implements ChildRepository {
  final ChildRemoteDataSource remoteDataSource;

  ChildRepositoryImpl(this.remoteDataSource);

  @override
  Future<Either<String, List<ChildEntity>>> getChildren(String userId) async {
    try {
      final children = await remoteDataSource.getChildren(userId);
      return Right(children);
    } catch (e) {
      return Left(e.toString());
    }
  }

  @override
  Future<Either<String, ChildEntity>> addChild(ChildEntity child) async {
    try {
      final added = await remoteDataSource.addChild(child);
      return Right(added);
    } catch (e) {
      return Left(e.toString());
    }
  }

  @override
  Future<Either<String, ChildEntity>> updateChild(ChildEntity child) async {
    try {
      final updated = await remoteDataSource.updateChild(child);
      return Right(updated);
    } catch (e) {
      return Left(e.toString());
    }
  }

  @override
  Future<Either<String, void>> deleteChild(String childId) async {
    try {
      await remoteDataSource.deleteChild(childId);
      return const Right(null);
    } catch (e) {
      return Left(e.toString());
    }
  }
}