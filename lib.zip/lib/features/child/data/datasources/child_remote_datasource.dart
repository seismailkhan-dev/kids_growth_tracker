// lib/features/child/data/datasources/child_remote_datasource.dart

import 'package:cloud_firestore/cloud_firestore.dart';
import '../../domain/entities/child_entity.dart';

abstract class ChildRemoteDataSource {
  Future<List<ChildEntity>> getChildren(String userId);
  Future<ChildEntity> addChild(ChildEntity child);
  Future<ChildEntity> updateChild(ChildEntity child);
  Future<void> deleteChild(String childId);
}

class ChildRemoteDataSourceImpl implements ChildRemoteDataSource {
  final FirebaseFirestore _db = FirebaseFirestore.instance;

  CollectionReference get _collection => _db.collection('children');

  @override
  Future<List<ChildEntity>> getChildren(String userId) async {
    final snapshot = await _collection
        .where('userId', isEqualTo: userId)
        .orderBy('name')
        .get();
    return snapshot.docs
        .map((doc) => ChildEntity.fromMap(doc.data() as Map<String, dynamic>))
        .toList();
  }

  @override
  Future<ChildEntity> addChild(ChildEntity child) async {
    final docRef = _collection.doc();
    final updated = ChildEntity(
      id: docRef.id,
      name: child.name,
      dateOfBirth: child.dateOfBirth,
      gender: child.gender,
      bloodGroup: child.bloodGroup,
      photoUrl: child.photoUrl,
      allergies: child.allergies,
      notes: child.notes,
      userId: child.userId,
    );
    await docRef.set(updated.toMap());
    return updated;
  }

  @override
  Future<ChildEntity> updateChild(ChildEntity child) async {
    await _collection.doc(child.id).update(child.toMap());
    return child;
  }

  @override
  Future<void> deleteChild(String childId) async {
    await _collection.doc(childId).delete();
  }
}
