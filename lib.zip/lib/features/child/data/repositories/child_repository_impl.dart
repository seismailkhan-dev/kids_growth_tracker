// lib/features/child/data/repositories/child_repository_impl.dart

import 'package:dartz/dartz.dart';
import '../../domain/entities/child_entity.dart';
import '../../domain/repositories/child_repository.dart';
import '../datasources/child_remote_datasource.dart';

class ChildRepositoryImpl implements ChildRepository {
  final ChildRemoteDataSource _dataSource;
  ChildRepositoryImpl(this._dataSource);

  @override
  Future<Either<String, List<ChildEntity>>> getChildren(String userId) async {
    try {
      final children = await _dataSource.getChildren(userId);
      return Right(children);
    } catch (e) {
      return Left(e.toString());
    }
  }

  @override
  Future<Either<String, ChildEntity>> addChild(ChildEntity child) async {
    try {
      final result = await _dataSource.addChild(child);
      return Right(result);
    } catch (e) {
      return Left(e.toString());
    }
  }

  @override
  Future<Either<String, ChildEntity>> updateChild(ChildEntity child) async {
    try {
      final result = await _dataSource.updateChild(child);
      return Right(result);
    } catch (e) {
      return Left(e.toString());
    }
  }

  @override
  Future<Either<String, void>> deleteChild(String childId) async {
    try {
      await _dataSource.deleteChild(childId);
      return const Right(null);
    } catch (e) {
      return Left(e.toString());
    }
  }
}
