// lib/features/child/presentation/controllers/child_controller.dart

import 'package:get/get.dart';
import 'package:uuid/uuid.dart';
import '../../domain/entities/child_entity.dart';
import '../../domain/usecases/get_children_usecase.dart';
import '../../domain/usecases/add_child_usecase.dart';
import '../../domain/usecases/update_child_usecase.dart';
import '../../domain/usecases/delete_child_usecase.dart';
import '../../../auth/presentation/controllers/auth_controller.dart';
import '../../../subscription/presentation/controllers/subscription_controller.dart';
import '../../../../core/constants/app_constants.dart';

class ChildController extends GetxController {
  final GetChildrenUseCase getChildrenUseCase;
  final AddChildUseCase addChildUseCase;
  final UpdateChildUseCase updateChildUseCase;
  final DeleteChildUseCase deleteChildUseCase;

  ChildController({
    required this.getChildrenUseCase,
    required this.addChildUseCase,
    required this.updateChildUseCase,
    required this.deleteChildUseCase,
  });

  final RxList<ChildEntity> children = <ChildEntity>[].obs;
  final RxBool isLoading = false.obs;
  final Rx<ChildEntity?> selectedChild = Rx<ChildEntity?>(null);

  @override
  void onInit() {
    super.onInit();
    loadChildren();
  }

  Future<void> loadChildren() async {
    isLoading.value = true;
    final authController = Get.find<AuthController>();
    final userId = authController.currentUser.value?.uid;
    if (userId == null) {
      isLoading.value = false;
      return;
    }
    final result = await getChildrenUseCase(userId);
    result.fold(
      (error) => Get.snackbar('Error', error),
      (list) => children.assignAll(list),
    );
    isLoading.value = false;
  }

  Future<bool> addChild({
    required String name,
    required DateTime dateOfBirth,
    required String gender,
    String? bloodGroup,
    String? allergies,
    String? notes,
    String? photoUrl,
  }) async {
    // Check free tier limit
    final subController = Get.find<SubscriptionController>();
    if (!subController.isPremium.value &&
        children.length >= AppConstants.freeChildLimit) {
      Get.toNamed('/subscription');
      return false;
    }

    final authController = Get.find<AuthController>();
    final userId = authController.currentUser.value!.uid;

    final child = ChildEntity(
      id: const Uuid().v4(),
      name: name,
      dateOfBirth: dateOfBirth,
      gender: gender,
      bloodGroup: bloodGroup,
      allergies: allergies,
      notes: notes,
      photoUrl: photoUrl,
      userId: userId,
    );

    isLoading.value = true;
    final result = await addChildUseCase(child);
    result.fold(
      (error) => Get.snackbar('Error', error),
      (newChild) => children.add(newChild),
    );
    isLoading.value = false;
    return result.isRight();
  }

  Future<void> updateChild(ChildEntity child) async {
    isLoading.value = true;
    final result = await updateChildUseCase(child);
    result.fold(
      (error) => Get.snackbar('Error', error),
      (updated) {
        final index = children.indexWhere((c) => c.id == updated.id);
        if (index != -1) children[index] = updated;
      },
    );
    isLoading.value = false;
  }

  Future<void> deleteChild(String childId) async {
    final result = await deleteChildUseCase(childId);
    result.fold(
      (error) => Get.snackbar('Error', error),
      (_) => children.removeWhere((c) => c.id == childId),
    );
  }

  void selectChild(ChildEntity child) {
    selectedChild.value = child;
  }
}
