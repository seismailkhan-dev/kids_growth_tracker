// lib/features/child/presentation/screens/add_child_screen.dart

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import '../../../../core/widgets/gradient_button.dart';
import '../../domain/entities/child_entity.dart';
import '../controllers/child_controller.dart';

class AddChildScreen extends StatefulWidget {
  const AddChildScreen({super.key});

  @override
  State<AddChildScreen> createState() => _AddChildScreenState();
}

class _AddChildScreenState extends State<AddChildScreen> {
  final _formKey = GlobalKey<FormState>();
  final _nameCtrl = TextEditingController();
  final _bloodGroupCtrl = TextEditingController();
  final _allergiesCtrl = TextEditingController();
  final _notesCtrl = TextEditingController();
  DateTime? _dateOfBirth;
  String _gender = 'Male';
  bool _isEditing = false;
  ChildEntity? _existingChild;

  @override
  void initState() {
    super.initState();
    _existingChild = Get.arguments as ChildEntity?;
    if (_existingChild != null) {
      _isEditing = true;
      _nameCtrl.text = _existingChild!.name;
      _dateOfBirth = _existingChild!.dateOfBirth;
      _gender = _existingChild!.gender;
      _bloodGroupCtrl.text = _existingChild!.bloodGroup ?? '';
      _allergiesCtrl.text = _existingChild!.allergies ?? '';
      _notesCtrl.text = _existingChild!.notes ?? '';
    }
  }

  @override
  void dispose() {
    _nameCtrl.dispose();
    _bloodGroupCtrl.dispose();
    _allergiesCtrl.dispose();
    _notesCtrl.dispose();
    super.dispose();
  }

  Future<void> _pickDate() async {
    final date = await showDatePicker(
      context: context,
      initialDate: _dateOfBirth ?? DateTime.now().subtract(const Duration(days: 365)),
      firstDate: DateTime(2000),
      lastDate: DateTime.now(),
    );
    if (date != null) setState(() => _dateOfBirth = date);
  }

  Future<void> _submit() async {
    if (!_formKey.currentState!.validate()) return;
    if (_dateOfBirth == null) {
      Get.snackbar('Error', 'Please select date of birth');
      return;
    }

    final controller = Get.find<ChildController>();

    if (_isEditing && _existingChild != null) {
      final updated = ChildEntity(
        id: _existingChild!.id,
        name: _nameCtrl.text.trim(),
        dateOfBirth: _dateOfBirth!,
        gender: _gender,
        bloodGroup: _bloodGroupCtrl.text.isNotEmpty ? _bloodGroupCtrl.text : null,
        allergies: _allergiesCtrl.text.isNotEmpty ? _allergiesCtrl.text : null,
        notes: _notesCtrl.text.isNotEmpty ? _notesCtrl.text : null,
        userId: _existingChild!.userId,
      );
      await controller.updateChild(updated);
      Get.back();
    } else {
      final success = await controller.addChild(
        name: _nameCtrl.text.trim(),
        dateOfBirth: _dateOfBirth!,
        gender: _gender,
        bloodGroup: _bloodGroupCtrl.text.isNotEmpty ? _bloodGroupCtrl.text : null,
        allergies: _allergiesCtrl.text.isNotEmpty ? _allergiesCtrl.text : null,
        notes: _notesCtrl.text.isNotEmpty ? _notesCtrl.text : null,
      );
      if (success) Get.back();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(_isEditing ? 'Edit Child Profile' : 'Add Child'),
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24),
          child: Form(
            key: _formKey,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Avatar placeholder
                Center(
                  child: Stack(
                    children: [
                      CircleAvatar(
                        radius: 50,
                        backgroundColor:
                            (_gender == 'Male' ? Colors.blue : Colors.pink).withOpacity(0.15),
                        child: Icon(
                          _gender == 'Male' ? Icons.boy : Icons.girl,
                          size: 60,
                          color: _gender == 'Male' ? Colors.blue : Colors.pink,
                        ),
                      ),
                      Positioned(
                        bottom: 0,
                        right: 0,
                        child: CircleAvatar(
                          radius: 16,
                          backgroundColor: Colors.grey.shade200,
                          child: const Icon(Icons.camera_alt, size: 16),
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 24),

                // Name
                TextFormField(
                  controller: _nameCtrl,
                  decoration: const InputDecoration(
                    labelText: 'Child\'s Name',
                    prefixIcon: Icon(Icons.person_outline),
                  ),
                  validator: (v) =>
                      v == null || v.isEmpty ? 'Name is required' : null,
                ),
                const SizedBox(height: 16),

                // Gender
                Text('Gender', style: Theme.of(context).textTheme.titleMedium),
                const SizedBox(height: 8),
                Row(
                  children: ['Male', 'Female', 'Other'].map((g) {
                    return Expanded(
                      child: Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 4),
                        child: ChoiceChip(
                          label: Text(g),
                          selected: _gender == g,
                          onSelected: (_) => setState(() => _gender = g),
                          selectedColor: g == 'Male' ? Colors.blue : Colors.pink,
                          labelStyle: TextStyle(
                            color: _gender == g ? Colors.white : null,
                          ),
                        ),
                      ),
                    );
                  }).toList(),
                ),
                const SizedBox(height: 16),

                // Date of birth
                GestureDetector(
                  onTap: _pickDate,
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
                    decoration: BoxDecoration(
                      border: Border.all(color: Colors.grey.shade300),
                      borderRadius: BorderRadius.circular(12),
                      color: Colors.grey.shade50,
                    ),
                    child: Row(
                      children: [
                        const Icon(Icons.cake_outlined, color: Colors.grey),
                        const SizedBox(width: 12),
                        Text(
                          _dateOfBirth != null
                              ? DateFormat('MMMM d, yyyy').format(_dateOfBirth!)
                              : 'Date of Birth',
                          style: TextStyle(
                            color: _dateOfBirth != null ? Colors.black87 : Colors.grey,
                          ),
                        ),
                        const Spacer(),
                        const Icon(Icons.calendar_today_outlined, color: Colors.grey, size: 18),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 16),

                // Blood group
                TextFormField(
                  controller: _bloodGroupCtrl,
                  decoration: const InputDecoration(
                    labelText: 'Blood Group (optional)',
                    prefixIcon: Icon(Icons.bloodtype_outlined),
                    hintText: 'e.g. A+, O-, AB+',
                  ),
                ),
                const SizedBox(height: 16),

                // Allergies
                TextFormField(
                  controller: _allergiesCtrl,
                  maxLines: 3,
                  decoration: const InputDecoration(
                    labelText: 'Known Allergies (optional)',
                    prefixIcon: Icon(Icons.warning_amber_outlined),
                    alignLabelWithHint: true,
                  ),
                ),
                const SizedBox(height: 16),

                // Notes
                TextFormField(
                  controller: _notesCtrl,
                  maxLines: 3,
                  decoration: const InputDecoration(
                    labelText: 'Notes (optional)',
                    prefixIcon: Icon(Icons.notes_outlined),
                    alignLabelWithHint: true,
                  ),
                ),
                const SizedBox(height: 32),

                Obx(() {
                  final controller = Get.find<ChildController>();
                  return GradientButton(
                    text: _isEditing ? 'Save Changes' : 'Add Child',
                    isLoading: controller.isLoading.value,
                    onPressed: _submit,
                  );
                }),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
