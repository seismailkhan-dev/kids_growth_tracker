// lib/features/child/presentation/screens/child_profile_screen.dart

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../../../core/constants/app_colors.dart';
import '../../../../core/routes/app_pages.dart';
import '../../../../core/widgets/app_card.dart';
import '../../domain/entities/child_entity.dart';
import '../controllers/child_controller.dart';

class ChildProfileScreen extends StatelessWidget {
  const ChildProfileScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final child = Get.arguments as ChildEntity?;
    if (child == null) {
      return const Scaffold(body: Center(child: Text('No child selected')));
    }
    final controller = Get.find<ChildController>();
    controller.selectChild(child);

    final age = _calculateAge(child.dateOfBirth);

    return Scaffold(
      body: CustomScrollView(
        slivers: [
          // Gradient header
          SliverAppBar(
            expandedHeight: 220,
            pinned: true,
            flexibleSpace: FlexibleSpaceBar(
              background: Container(
                decoration: BoxDecoration(
                  gradient: child.gender == 'Male'
                      ? const LinearGradient(
                          colors: [Color(0xFF87CEFA), Color(0xFF6C63FF)],
                          begin: Alignment.topLeft,
                          end: Alignment.bottomRight,
                        )
                      : AppColors.pinkGradient,
                ),
                child: Padding(
                  padding: const EdgeInsets.only(bottom: 24),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      CircleAvatar(
                        radius: 44,
                        backgroundColor: Colors.white.withOpacity(0.3),
                        backgroundImage: child.photoUrl != null
                            ? NetworkImage(child.photoUrl!)
                            : null,
                        child: child.photoUrl == null
                            ? Icon(
                                child.gender == 'Male' ? Icons.boy : Icons.girl,
                                size: 48,
                                color: Colors.white,
                              )
                            : null,
                      ),
                      const SizedBox(height: 12),
                      Text(
                        child.name,
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 24,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                      Text(
                        '$age • ${child.gender}',
                        style: TextStyle(
                          color: Colors.white.withOpacity(0.85),
                          fontSize: 14,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
            actions: [
              IconButton(
                icon: const Icon(Icons.edit, color: Colors.white),
                onPressed: () => Get.toNamed(Routes.addChild, arguments: child),
              ),
              PopupMenuButton(
                icon: const Icon(Icons.more_vert, color: Colors.white),
                itemBuilder: (_) => [
                  PopupMenuItem(
                    value: 'delete',
                    child: const Row(
                      children: [
                        Icon(Icons.delete, color: Colors.red),
                        SizedBox(width: 8),
                        Text('Delete Profile', style: TextStyle(color: Colors.red)),
                      ],
                    ),
                  ),
                ],
                onSelected: (value) async {
                  if (value == 'delete') {
                    final confirm = await Get.dialog<bool>(
                      AlertDialog(
                        title: const Text('Delete Profile?'),
                        content: Text('Are you sure you want to delete ${child.name}\'s profile?'),
                        actions: [
                          TextButton(
                              onPressed: () => Get.back(result: false),
                              child: const Text('Cancel')),
                          ElevatedButton(
                            onPressed: () => Get.back(result: true),
                            style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
                            child: const Text('Delete'),
                          ),
                        ],
                      ),
                    );
                    if (confirm == true) {
                      await controller.deleteChild(child.id);
                      Get.back();
                    }
                  }
                },
              ),
            ],
          ),

          // Info cards
          SliverPadding(
            padding: const EdgeInsets.all(20),
            sliver: SliverList(
              delegate: SliverChildListDelegate([
                // Stats row
                Row(
                  children: [
                    _InfoChip(
                      label: 'Blood Group',
                      value: child.bloodGroup ?? 'N/A',
                      icon: Icons.bloodtype,
                    ),
                    const SizedBox(width: 12),
                    _InfoChip(
                      label: 'Date of Birth',
                      value: _formatDate(child.dateOfBirth),
                      icon: Icons.cake,
                    ),
                  ],
                ),
                const SizedBox(height: 16),

                // Allergies
                if (child.allergies != null && child.allergies!.isNotEmpty)
                  AppCard(
                    margin: const EdgeInsets.only(bottom: 16),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            const Icon(Icons.warning_amber, color: Colors.orange, size: 20),
                            const SizedBox(width: 8),
                            const Text(
                              'Allergies',
                              style: TextStyle(fontWeight: FontWeight.w600),
                            ),
                          ],
                        ),
                        const SizedBox(height: 8),
                        Text(child.allergies!),
                      ],
                    ),
                  ),

                // Notes
                if (child.notes != null && child.notes!.isNotEmpty)
                  AppCard(
                    margin: const EdgeInsets.only(bottom: 16),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text('Notes', style: TextStyle(fontWeight: FontWeight.w600)),
                        const SizedBox(height: 8),
                        Text(child.notes!),
                      ],
                    ),
                  ),

                // Action buttons grid
                const SizedBox(height: 8),
                _SectionTitle('Health Tracking'),
                const SizedBox(height: 12),
                _ActionGrid(child: child),
              ]),
            ),
          ),
        ],
      ),
    );
  }

  String _calculateAge(DateTime dob) {
    final now = DateTime.now();
    int years = now.year - dob.year;
    int months = now.month - dob.month;
    if (months < 0) { years--; months += 12; }
    if (years > 0) return '$years yr${years > 1 ? 's' : ''} $months mo';
    return '$months months';
  }

  String _formatDate(DateTime date) =>
      '${date.day}/${date.month}/${date.year}';
}

class _InfoChip extends StatelessWidget {
  final String label;
  final String value;
  final IconData icon;

  const _InfoChip({required this.label, required this.value, required this.icon});

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: AppColors.primary.withOpacity(0.08),
          borderRadius: BorderRadius.circular(12),
        ),
        child: Row(
          children: [
            Icon(icon, color: AppColors.primary, size: 20),
            const SizedBox(width: 8),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(label, style: const TextStyle(fontSize: 11, color: AppColors.textHint)),
                Text(value, style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 13)),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class _SectionTitle extends StatelessWidget {
  final String title;
  const _SectionTitle(this.title);

  @override
  Widget build(BuildContext context) =>
      Text(title, style: Theme.of(context).textTheme.headlineSmall);
}

class _ActionGrid extends StatelessWidget {
  final ChildEntity child;
  const _ActionGrid({required this.child});

  @override
  Widget build(BuildContext context) {
    final actions = [
      {'title': 'Growth', 'icon': Icons.show_chart, 'route': Routes.growthTracker, 'color': AppColors.pink},
      {'title': 'Sleep', 'icon': Icons.bedtime, 'route': Routes.sleepTracker, 'color': AppColors.lightBlue},
      {'title': 'Medical', 'icon': Icons.medical_services_outlined, 'route': Routes.medicalHistory, 'color': AppColors.mistyRose},
      {'title': 'Activities', 'icon': Icons.directions_run, 'route': Routes.activities, 'color': AppColors.lightGreen},
    ];

    return GridView.builder(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2,
        crossAxisSpacing: 12,
        mainAxisSpacing: 12,
        childAspectRatio: 1.8,
      ),
      itemCount: actions.length,
      itemBuilder: (context, i) {
        final action = actions[i];
        final color = action['color'] as Color;
        return GestureDetector(
          onTap: () => Get.toNamed(action['route'] as String, arguments: child),
          child: Container(
            decoration: BoxDecoration(
              color: color.withOpacity(0.12),
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: color.withOpacity(0.2)),
            ),
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
            child: Row(
              children: [
                Icon(action['icon'] as IconData, color: color, size: 28),
                const SizedBox(width: 10),
                Text(
                  action['title'] as String,
                  style: TextStyle(color: color, fontWeight: FontWeight.w600),
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}
