// lib/core/constants/app_colors.dart

import 'package:flutter/material.dart';

class AppColors {
  AppColors._();

  // Primary pastel palette
  static const Color pink = Color(0xFFFFB6C1);
  static const Color lightBlue = Color(0xFF87CEFA);
  static const Color gold = Color(0xFFFFD700);
  static const Color lightGreen = Color(0xFFE0FFE0);
  static const Color mistyRose = Color(0xFFFFE4E1);

  // Main brand colors
  static const Color primary = Color(0xFF6C63FF);
  static const Color primaryLight = Color(0xFF9C95FF);
  static const Color primaryDark = Color(0xFF3D35CC);

  static const Color secondary = Color(0xFFFF6584);
  static const Color secondaryLight = Color(0xFFFF9AAE);
  static const Color secondaryDark = Color(0xFFCC3358);

  static const Color accent = Color(0xFF43D9AD);

  // Neutral
  static const Color background = Color(0xFFF8F9FF);
  static const Color surface = Color(0xFFFFFFFF);
  static const Color cardBg = Color(0xFFFFFFFF);

  // Dark mode
  static const Color darkBackground = Color(0xFF1A1A2E);
  static const Color darkSurface = Color(0xFF16213E);
  static const Color darkCard = Color(0xFF0F3460);

  // Text
  static const Color textPrimary = Color(0xFF2D2D3F);
  static const Color textSecondary = Color(0xFF6B6B8A);
  static const Color textHint = Color(0xFFAAAAAD);
  static const Color textOnDark = Color(0xFFFFFFFF);

  // Status
  static const Color success = Color(0xFF4CAF50);
  static const Color warning = Color(0xFFFFC107);
  static const Color error = Color(0xFFE53935);
  static const Color info = Color(0xFF2196F3);

  // Chart colors
  static const List<Color> chartColors = [
    Color(0xFF6C63FF),
    Color(0xFFFF6584),
    Color(0xFF43D9AD),
    Color(0xFFFFD700),
    Color(0xFF87CEFA),
  ];

  // Gradients
  static const LinearGradient primaryGradient = LinearGradient(
    colors: [Color(0xFF6C63FF), Color(0xFF9C95FF)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );

  static const LinearGradient pinkGradient = LinearGradient(
    colors: [Color(0xFFFF6584), Color(0xFFFFB6C1)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );

  static const LinearGradient greenGradient = LinearGradient(
    colors: [Color(0xFF43D9AD), Color(0xFFE0FFE0)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );
}
