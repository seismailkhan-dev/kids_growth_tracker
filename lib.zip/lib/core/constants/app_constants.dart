// lib/core/constants/app_constants.dart

class AppConstants {
  AppConstants._();

  static const String appName = 'Family Health Tracker';
  static const String appVersion = '1.0.0';

  // Firestore Collections
  static const String usersCollection = 'users';
  static const String childrenCollection = 'children';
  static const String growthCollection = 'growth_records';
  static const String sleepCollection = 'sleep_records';
  static const String activitiesCollection = 'activities';
  static const String medicalCollection = 'medical_records';
  static const String insightsCollection = 'ai_insights';

  // Hive Boxes
  static const String settingsBox = 'settings';
  static const String cacheBox = 'cache';
  static const String userBox = 'user';

  // Subscription Product IDs
  static const String monthlySubId = 'family_health_premium_monthly';
  static const String yearlySubId = 'family_health_premium_yearly';

  // AdMob Ad Unit IDs (replace with real IDs in production)
  static const String bannerAdUnitId = 'ca-app-pub-3940256099942544/6300978111'; // Test ID
  static const String nativeAdUnitId = 'ca-app-pub-3940256099942544/2247696110'; // Test ID

  // Free tier limits
  static const int freeChildLimit = 1;
  static const int freeGrowthRecordsLimit = 10;

  // Animation durations
  static const Duration shortAnimation = Duration(milliseconds: 200);
  static const Duration mediumAnimation = Duration(milliseconds: 400);
  static const Duration longAnimation = Duration(milliseconds: 800);
}
