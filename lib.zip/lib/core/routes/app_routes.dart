// lib/core/routes/app_routes.dart

part of 'app_pages.dart';

abstract class Routes {
  Routes._();

  static const splash = '/';
  static const onboarding = '/onboarding';
  static const login = '/login';
  static const signup = '/signup';
  static const forgotPassword = '/forgot-password';
  static const dashboard = '/dashboard';
  static const childProfile = '/child-profile';
  static const addChild = '/add-child';
  static const growthTracker = '/growth-tracker';
  static const sleepTracker = '/sleep-tracker';
  static const activities = '/activities';
  static const medicalHistory = '/medical-history';
  static const aiInsights = '/ai-insights';
  static const reports = '/reports';
  static const subscription = '/subscription';
  static const settings = '/settings';
  static const notifications = '/notifications';
}
