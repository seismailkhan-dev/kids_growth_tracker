// lib/core/routes/app_pages.dart
// Centralized routing for all screens using GetX

import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../features/auth/presentation/screens/login_screen.dart';
import '../../features/auth/presentation/screens/signup_screen.dart';
import '../../features/auth/presentation/screens/forgot_password_screen.dart';
import '../../features/auth/presentation/screens/splash_screen.dart';
import '../../features/onboarding/presentation/screens/onboarding_screen.dart';
import '../../features/dashboard/presentation/screens/dashboard_screen.dart';
import '../../features/child/presentation/screens/child_profile_screen.dart';
import '../../features/child/presentation/screens/add_child_screen.dart';
import '../../features/growth/presentation/screens/growth_tracker_screen.dart';
import '../../features/sleep/presentation/screens/sleep_tracker_screen.dart';
import '../../features/activities/presentation/screens/activities_screen.dart';
import '../../features/medical/presentation/screens/medical_history_screen.dart';
import '../../features/ai_insights/presentation/screens/ai_insights_screen.dart';
import '../../features/reports/presentation/screens/reports_screen.dart';
import '../../features/subscription/presentation/screens/subscription_screen.dart';
import '../../features/settings/presentation/screens/settings_screen.dart';
import '../../features/notifications/presentation/screens/notifications_screen.dart';

import '../bindings/auth_binding.dart';
import '../bindings/dashboard_binding.dart';
import '../bindings/child_binding.dart';
import '../bindings/growth_binding.dart';
import '../bindings/sleep_binding.dart';
import '../bindings/subscription_binding.dart';

part 'app_routes.dart';

class AppPages {
  AppPages._();

  static const initial = Routes.splash;

  static final routes = [
    GetPage(
      name: Routes.splash,
      page: () => const SplashScreen(),
      binding: AuthBinding(),
    ),
    GetPage(
      name: Routes.onboarding,
      page: () => const OnboardingScreen(),
    ),
    GetPage(
      name: Routes.login,
      page: () => const LoginScreen(),
      binding: AuthBinding(),
    ),
    GetPage(
      name: Routes.signup,
      page: () => const SignupScreen(),
      binding: AuthBinding(),
    ),
    GetPage(
      name: Routes.forgotPassword,
      page: () => const ForgotPasswordScreen(),
      binding: AuthBinding(),
    ),
    GetPage(
      name: Routes.dashboard,
      page: () => const DashboardScreen(),
      binding: DashboardBinding(),
    ),
    GetPage(
      name: Routes.childProfile,
      page: () => const ChildProfileScreen(),
      binding: ChildBinding(),
    ),
    GetPage(
      name: Routes.addChild,
      page: () => const AddChildScreen(),
      binding: ChildBinding(),
    ),
    GetPage(
      name: Routes.growthTracker,
      page: () => const GrowthTrackerScreen(),
      binding: GrowthBinding(),
    ),
    GetPage(
      name: Routes.sleepTracker,
      page: () => const SleepTrackerScreen(),
      binding: SleepBinding(),
    ),
    GetPage(
      name: Routes.activities,
      page: () => const ActivitiesScreen(),
    ),
    GetPage(
      name: Routes.medicalHistory,
      page: () => const MedicalHistoryScreen(),
    ),
    GetPage(
      name: Routes.aiInsights,
      page: () => const AiInsightsScreen(),
      middlewares: [PremiumMiddleware()],
    ),
    GetPage(
      name: Routes.reports,
      page: () => const ReportsScreen(),
      middlewares: [PremiumMiddleware()],
    ),
    GetPage(
      name: Routes.subscription,
      page: () => const SubscriptionScreen(),
      binding: SubscriptionBinding(),
    ),
    GetPage(
      name: Routes.settings,
      page: () => const SettingsScreen(),
    ),
    GetPage(
      name: Routes.notifications,
      page: () => const NotificationsScreen(),
    ),
  ];
}

/// Middleware to guard premium-only routes
class PremiumMiddleware extends GetMiddleware {
  @override
  RouteSettings? redirect(String? route) {
    // Import subscription service and check premium status
    // If not premium, redirect to subscription paywall
    return null; // Handled in each screen's controller
  }
}
