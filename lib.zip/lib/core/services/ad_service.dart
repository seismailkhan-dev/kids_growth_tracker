// lib/core/services/ad_service.dart
// Manages Google AdMob initialization and ad loading

import 'package:get/get.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';
import '../constants/app_constants.dart';

class AdService extends GetxService {
  BannerAd? _bannerAd;
  final RxBool isBannerLoaded = false.obs;

  Future<void> initialize() async {
    // This must run after Flutter bindings and Firebase
    await MobileAds.instance.initialize();
  }

  // @override
  // void onInit() {
  //   super.onInit();
  //   MobileAds.instance.initialize();
  // }

  void loadBannerAd() {
    _bannerAd = BannerAd(
      adUnitId: AppConstants.bannerAdUnitId,
      size: AdSize.banner,
      request: const AdRequest(),
      listener: BannerAdListener(
        onAdLoaded: (_) => isBannerLoaded.value = true,
        onAdFailedToLoad: (ad, error) {
          ad.dispose();
          isBannerLoaded.value = false;
        },
      ),
    )..load();
  }

  BannerAd? get bannerAd => _bannerAd;

  @override
  void onClose() {
    _bannerAd?.dispose();
    super.onClose();
  }
}
