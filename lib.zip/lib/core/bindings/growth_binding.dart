// lib/core/bindings/growth_binding.dart
import 'package:get/get.dart';
import '../../features/growth/data/datasources/growth_remote_datasource.dart';
import '../../features/growth/data/repositories/growth_repository_impl.dart';
import '../../features/growth/domain/repositories/growth_repository.dart';
import '../../features/growth/domain/usecases/get_growth_records_usecase.dart';
import '../../features/growth/domain/usecases/add_growth_record_usecase.dart';
import '../../features/growth/presentation/controllers/growth_controller.dart';

class GrowthBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut<GrowthRemoteDataSource>(() => GrowthRemoteDataSourceImpl());
    Get.lazyPut<GrowthRepository>(() => GrowthRepositoryImpl(Get.find()));
    Get.lazyPut(() => GetGrowthRecordsUseCase(Get.find<GrowthRepository>()));
    Get.lazyPut(() => AddGrowthRecordUseCase(Get.find<GrowthRepository>()));
    Get.lazyPut(() => GrowthController(
      getGrowthRecords: Get.find(),
      addGrowthRecord: Get.find(),
    ));
  }
}

// lib/core/bindings/sleep_binding.dart
