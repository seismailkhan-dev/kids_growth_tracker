// lib/core/bindings/subscription_binding.dart
import 'package:get/get.dart';
import '../../features/subscription/domain/repositories/subscription_repository.dart';
import '../../features/subscription/domain/usecases/get_subscription_status_usecase.dart';
import '../../features/subscription/domain/usecases/purchase_subscription_usecase.dart';
import '../../features/subscription/presentation/controllers/subscription_controller.dart';

class SubscriptionBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut(() => GetSubscriptionStatusUseCase(Get.find<SubscriptionRepository>()));
    Get.lazyPut(() => PurchaseSubscriptionUseCase(Get.find<SubscriptionRepository>()));
    Get.lazyPut(() => SubscriptionController(
      getStatus: Get.find(),
      purchaseSubscription: Get.find(),
    ));
  }
}
