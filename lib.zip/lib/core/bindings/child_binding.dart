// lib/core/bindings/child_binding.dart
import 'package:get/get.dart';
import '../../features/child/data/datasources/child_remote_datasource.dart';
import '../../features/child/data/repositories/child_repository_impl.dart' hide ChildRepositoryImpl;
import '../../features/child/domain/repositories/child_repository.dart';
import '../../features/child/domain/usecases/get_children_usecase.dart';
import '../../features/child/domain/usecases/add_child_usecase.dart';
import '../../features/child/domain/usecases/update_child_usecase.dart';
import '../../features/child/domain/usecases/delete_child_usecase.dart';
import '../../features/child/presentation/controllers/child_controller.dart';

class ChildBinding extends Bindings {
  @override
  void dependencies() {
    if (!Get.isRegistered<ChildRemoteDataSource>()) {
      Get.lazyPut<ChildRemoteDataSource>(() => ChildRemoteDataSourceImpl());
    }
    if (!Get.isRegistered<ChildRepository>()) {
      Get.lazyPut<ChildRepository>(() => ChildRepositoryImpl(Get.find()));
    }
    Get.lazyPut(() => GetChildrenUseCase(Get.find<ChildRepository>()));
    Get.lazyPut(() => AddChildUseCase(Get.find<ChildRepository>()));
    Get.lazyPut(() => UpdateChildUseCase(Get.find<ChildRepository>()));
    Get.lazyPut(() => DeleteChildUseCase(Get.find<ChildRepository>()));
    Get.lazyPut(() => ChildController(
      getChildrenUseCase: Get.find(),
      addChildUseCase: Get.find(),
      updateChildUseCase: Get.find(),
      deleteChildUseCase: Get.find(),
    ));
  }
}
