// lib/core/bindings/initial_binding.dart
// Sets up all global services at app launch

import 'package:family_health_tracker/features/subscription/domain/usecases/get_subscription_status_usecase.dart';
import 'package:family_health_tracker/features/subscription/domain/usecases/purchase_subscription_usecase.dart';
import 'package:get/get.dart';
import '../../features/auth/data/datasources/auth_remote_datasource.dart';
import '../../features/auth/data/repositories/auth_repository_impl.dart';
import '../../features/auth/domain/repositories/auth_repository.dart';
import '../../features/auth/domain/usecases/google_signin_usecase.dart';
import '../../features/auth/domain/usecases/login_usecase.dart';
import '../../features/auth/domain/usecases/logout_usecase.dart';
import '../../features/auth/domain/usecases/signup_usecase.dart';
import '../../features/auth/presentation/controllers/auth_controller.dart';
import '../../features/child/data/datasources/child_remote_datasource.dart';
import '../../features/child/data/repositories/child_repository_impl.dart';
import '../../features/child/domain/usecases/get_children_usecase.dart';
import '../../features/dashboard/presentation/controllers/dashboard_controller.dart';
import '../../features/subscription/data/datasources/subscription_datasource.dart';
import '../../features/subscription/data/repositories/subscription_repository_impl.dart';
import '../../features/subscription/domain/repositories/subscription_repository.dart';
import '../../features/subscription/presentation/controllers/subscription_controller.dart';
import '../services/ad_service.dart';
import '../services/notification_service.dart';
import '../services/storage_service.dart';
import '../services/analytics_service.dart';

class InitialBinding extends GetxController {
  @override
  void onInit() {
    super.onInit();

    Get.put<AuthController>(AuthController(), permanent: true);
    Get.put<AuthRemoteDataSource>(AuthRemoteDataSourceImpl(), permanent: true);

    Get.put<AuthRepository>(
      AuthRepositoryImpl(Get.find<AuthRemoteDataSource>()),
      permanent: true,
    );
    Get.put<LoginUseCase>(LoginUseCase(Get.find<AuthRepository>()), permanent: true);
    Get.put<SignupUseCase>(SignupUseCase(Get.find<AuthRepository>()), permanent: true);
    Get.put<LogoutUseCase>(LogoutUseCase(Get.find<AuthRepository>()), permanent: true);
    Get.put<GoogleSignInUseCase>(GoogleSignInUseCase(Get.find<AuthRepository>()), permanent: true);

    // Core services - permanent (never disposed)
    Get.put<StorageService>(StorageService(), permanent: true);
    Get.put<NotificationService>(NotificationService(), permanent: true);
    Get.put<AdService>(AdService(), permanent: true);
    Get.put<AnalyticsService>(AnalyticsService(), permanent: true);

    // Auth datasource and repository

    // lib/core/bindings/initial_binding.dart

  }
}
