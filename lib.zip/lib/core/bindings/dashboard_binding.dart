// lib/core/bindings/dashboard_binding.dart
import 'package:get/get.dart';
import '../../features/child/data/datasources/child_remote_datasource.dart';
import '../../features/child/data/repositories/child_repository_impl.dart' hide ChildRepositoryImpl;
import '../../features/child/domain/repositories/child_repository.dart';
import '../../features/child/domain/usecases/get_children_usecase.dart';
import '../../features/dashboard/presentation/controllers/dashboard_controller.dart';

class DashboardBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut<ChildRemoteDataSource>(() => ChildRemoteDataSourceImpl());
    Get.lazyPut<ChildRepository>(() => ChildRepositoryImpl(Get.find()));
    Get.lazyPut(() => GetChildrenUseCase(Get.find<ChildRepository>()));
    Get.lazyPut(() => DashboardController(
    ));
  }
}
