// lib/core/bindings/sleep_binding.dart
import 'package:get/get.dart';
import '../../features/sleep/data/datasources/sleep_remote_datasource.dart';
import '../../features/sleep/data/repositories/sleep_repository_impl.dart';
import '../../features/sleep/domain/repositories/sleep_repository.dart';
import '../../features/sleep/domain/usecases/get_sleep_records_usecase.dart';
import '../../features/sleep/domain/usecases/add_sleep_record_usecase.dart';
import '../../features/sleep/presentation/controllers/sleep_controller.dart';

class SleepBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut<SleepRemoteDataSource>(() => SleepRemoteDataSourceImpl());
    Get.lazyPut<SleepRepository>(() => SleepRepositoryImpl(Get.find()));
    Get.lazyPut(() => GetSleepRecordsUseCase(Get.find<SleepRepository>()));
    Get.lazyPut(() => AddSleepRecordUseCase(Get.find<SleepRepository>()));
    Get.lazyPut(() => SleepController(
      getSleepRecords: Get.find(),
      addSleepRecord: Get.find(),
    ));
  }
}
