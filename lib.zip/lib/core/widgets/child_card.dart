// lib/core/widgets/child_card.dart

import 'package:flutter/material.dart';
import '../constants/app_colors.dart';
import '../../features/child/domain/entities/child_entity.dart';

class ChildCard extends StatelessWidget {
  final ChildEntity child;
  final VoidCallback onTap;
  final VoidCallback? onDelete;

  const ChildCard({
    super.key,
    required this.child,
    required this.onTap,
    this.onDelete,
  });

  @override
  Widget build(BuildContext context) {
    final age = _calculateAge(child.dateOfBirth);
    final gradient = child.gender == 'Male'
        ? const LinearGradient(
            colors: [Color(0xFF87CEFA), Color(0xFF6C63FF)],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          )
        : AppColors.pinkGradient;

    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 160,
        margin: const EdgeInsets.only(right: 12),
        decoration: BoxDecoration(
          gradient: gradient,
          borderRadius: BorderRadius.circular(20),
          boxShadow: [
            BoxShadow(
              color: AppColors.primary.withOpacity(0.2),
              blurRadius: 12,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Avatar
              Container(
                width: 60,
                height: 60,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: Colors.white.withOpacity(0.3),
                ),
                child: child.photoUrl != null
                    ? ClipOval(
                        child: Image.network(
                          child.photoUrl!,
                          fit: BoxFit.cover,
                        ),
                      )
                    : Icon(
                        child.gender == 'Male' ? Icons.boy : Icons.girl,
                        size: 36,
                        color: Colors.white,
                      ),
              ),
              const SizedBox(height: 12),
              // Name
              Text(
                child.name,
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 16,
                  fontWeight: FontWeight.w700,
                ),
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
              ),
              const SizedBox(height: 4),
              // Age
              Text(
                age,
                style: TextStyle(
                  color: Colors.white.withOpacity(0.85),
                  fontSize: 13,
                ),
              ),
              const Spacer(),
              // Blood group badge
              if (child.bloodGroup != null)
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                  decoration: BoxDecoration(
                    color: Colors.white.withOpacity(0.25),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Text(
                    child.bloodGroup!,
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 12,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }

  String _calculateAge(DateTime dob) {
    final now = DateTime.now();
    int years = now.year - dob.year;
    int months = now.month - dob.month;
    if (months < 0) {
      years--;
      months += 12;
    }
    if (years > 0) return '$years yr${years > 1 ? 's' : ''}';
    return '$months mo';
  }
}
