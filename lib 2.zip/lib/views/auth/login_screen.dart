// lib/views/auth/login_screen.dart
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../core/theme/app_theme.dart';
import '../../core/widgets/app_widgets.dart';
import '../dashboard/dashboard_screen.dart';
import 'signup_screen.dart';
import 'forgot_password_screen.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _emailController = TextEditingController(text: 'hello@family.com');
  final _passwordController = TextEditingController(text: '••••••••');
  bool _obscure = true;
  bool _loading = false;

  void _login() {
    setState(() => _loading = true);
    Future.delayed(const Duration(seconds: 2), () {
      setState(() => _loading = false);
      Get.offAll(() => const DashboardScreen());
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const SizedBox(height: 20),
              Center(
                child: Container(
                  width: 80,
                  height: 80,
                  decoration: BoxDecoration(
                    gradient: AppColors.gradient1,
                    shape: BoxShape.circle,
                    boxShadow: [BoxShadow(color: AppColors.pink.withOpacity(0.4), blurRadius: 16, offset: const Offset(0, 6))],
                  ),
                  child: const Center(child: Text('🌱', style: TextStyle(fontSize: 38))),
                ),
              ),
              const SizedBox(height: 32),
              Text('Welcome Back! 👋', style: Theme.of(context).textTheme.headlineLarge),
              const SizedBox(height: 8),
              Text('Sign in to continue tracking your little ones', style: Theme.of(context).textTheme.bodyMedium?.copyWith(color: AppColors.textSecondary)),
              const SizedBox(height: 36),
              _buildLabel('Email Address'),
              const SizedBox(height: 8),
              TextFormField(
                controller: _emailController,
                keyboardType: TextInputType.emailAddress,
                decoration: const InputDecoration(prefixIcon: Icon(Icons.mail_outline_rounded), hintText: 'your@email.com'),
              ),
              const SizedBox(height: 20),
              _buildLabel('Password'),
              const SizedBox(height: 8),
              TextFormField(
                controller: _passwordController,
                obscureText: _obscure,
                decoration: InputDecoration(
                  prefixIcon: const Icon(Icons.lock_outline_rounded),
                  hintText: '••••••••',
                  suffixIcon: GestureDetector(
                    onTap: () => setState(() => _obscure = !_obscure),
                    child: Icon(_obscure ? Icons.visibility_off_outlined : Icons.visibility_outlined),
                  ),
                ),
              ),
              const SizedBox(height: 12),
              Align(
                alignment: Alignment.centerRight,
                child: TextButton(
                  onPressed: () => Get.to(() => const ForgotPasswordScreen()),
                  child: const Text('Forgot Password?', style: TextStyle(color: AppColors.pink, fontWeight: FontWeight.w600)),
                ),
              ),
              const SizedBox(height: 24),
              GradientButton(label: _loading ? 'Signing in...' : 'Sign In', onTap: _loading ? () {} : _login, icon: Icons.login_rounded),
              const SizedBox(height: 16),
              _buildDivider(),
              const SizedBox(height: 16),
              _buildSocialButton('Continue with Google', '🇬', Colors.white),
              const SizedBox(height: 12),
              _buildSocialButton('Continue with Apple', '🍎', Colors.black, textColor: Colors.white),
              const SizedBox(height: 32),
              Center(
                child: GestureDetector(
                  onTap: () => Get.to(() => const SignupScreen()),
                  child: RichText(
                    text: const TextSpan(
                      text: "Don't have an account? ",
                      style: TextStyle(color: AppColors.textSecondary, fontSize: 14),
                      children: [TextSpan(text: 'Sign Up', style: TextStyle(color: AppColors.pink, fontWeight: FontWeight.w700))],
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildLabel(String text) => Text(text, style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 14));

  Widget _buildDivider() => Row(children: [
    Expanded(child: Divider(color: Colors.grey.withOpacity(0.3))),
    const Padding(padding: EdgeInsets.symmetric(horizontal: 12), child: Text('OR', style: TextStyle(color: AppColors.textSecondary, fontWeight: FontWeight.w500))),
    Expanded(child: Divider(color: Colors.grey.withOpacity(0.3))),
  ]);

  Widget _buildSocialButton(String label, String icon, Color bg, {Color textColor = const Color(0xFF2D2D2D)}) {
    return Container(
      width: double.infinity,
      height: 52,
      decoration: BoxDecoration(
        color: bg,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.grey.withOpacity(0.3)),
        boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.05), blurRadius: 8, offset: const Offset(0, 2))],
      ),
      child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
        Text(icon, style: const TextStyle(fontSize: 20)),
        const SizedBox(width: 10),
        Text(label, style: TextStyle(color: textColor, fontWeight: FontWeight.w600, fontSize: 15)),
      ]),
    );
  }
}
