// lib/views/auth/signup_screen.dart
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../core/theme/app_theme.dart';
import '../../core/widgets/app_widgets.dart';
import '../dashboard/dashboard_screen.dart';

class SignupScreen extends StatefulWidget {
  const SignupScreen({super.key});

  @override
  State<SignupScreen> createState() => _SignupScreenState();
}

class _SignupScreenState extends State<SignupScreen> {
  bool _obscure = true;
  bool _loading = false;
  bool _agreeTerms = false;

  void _signup() {
    setState(() => _loading = true);
    Future.delayed(const Duration(seconds: 2), () {
      setState(() => _loading = false);
      Get.offAll(() => const DashboardScreen());
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(leading: const BackButton()),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('Create Account 🎉', style: Theme.of(context).textTheme.headlineLarge),
              const SizedBox(height: 8),
              Text('Join thousands of families on GrowthBuddy', style: Theme.of(context).textTheme.bodyMedium?.copyWith(color: AppColors.textSecondary)),
              const SizedBox(height: 32),
              Row(children: [
                Expanded(child: _field('First Name', Icons.person_outline_rounded, 'Jane')),
                const SizedBox(width: 12),
                Expanded(child: _field('Last Name', Icons.person_outline_rounded, 'Doe')),
              ]),
              const SizedBox(height: 16),
              _field('Email Address', Icons.mail_outline_rounded, 'jane@example.com', type: TextInputType.emailAddress),
              const SizedBox(height: 16),
              _field('Phone Number', Icons.phone_outlined, '+1 555 000 0000', type: TextInputType.phone),
              const SizedBox(height: 16),
              TextFormField(
                obscureText: _obscure,
                decoration: InputDecoration(
                  labelText: 'Password',
                  prefixIcon: const Icon(Icons.lock_outline_rounded),
                  suffixIcon: GestureDetector(
                    onTap: () => setState(() => _obscure = !_obscure),
                    child: Icon(_obscure ? Icons.visibility_off_outlined : Icons.visibility_outlined),
                  ),
                ),
              ),
              const SizedBox(height: 16),
              TextFormField(
                obscureText: true,
                decoration: const InputDecoration(labelText: 'Confirm Password', prefixIcon: Icon(Icons.lock_outline_rounded)),
              ),
              const SizedBox(height: 20),
              GestureDetector(
                onTap: () => setState(() => _agreeTerms = !_agreeTerms),
                child: Row(children: [
                  Checkbox(
                    value: _agreeTerms,
                    onChanged: (v) => setState(() => _agreeTerms = v!),
                    activeColor: AppColors.pink,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(4)),
                  ),
                  Expanded(
                    child: RichText(
                      text: const TextSpan(
                        text: 'I agree to the ',
                        style: TextStyle(color: AppColors.textSecondary, fontSize: 13),
                        children: [
                          TextSpan(text: 'Terms of Service', style: TextStyle(color: AppColors.pink, fontWeight: FontWeight.w600)),
                          TextSpan(text: ' and '),
                          TextSpan(text: 'Privacy Policy', style: TextStyle(color: AppColors.pink, fontWeight: FontWeight.w600)),
                        ],
                      ),
                    ),
                  ),
                ]),
              ),
              const SizedBox(height: 28),
              GradientButton(label: _loading ? 'Creating account...' : 'Create Account', onTap: _loading ? () {} : _signup),
              const SizedBox(height: 24),
              Center(
                child: GestureDetector(
                  onTap: () => Get.back(),
                  child: RichText(
                    text: const TextSpan(
                      text: 'Already have an account? ',
                      style: TextStyle(color: AppColors.textSecondary, fontSize: 14),
                      children: [TextSpan(text: 'Sign In', style: TextStyle(color: AppColors.pink, fontWeight: FontWeight.w700))],
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _field(String label, IconData icon, String hint, {TextInputType type = TextInputType.text}) {
    return TextFormField(
      keyboardType: type,
      decoration: InputDecoration(labelText: label, prefixIcon: Icon(icon), hintText: hint),
    );
  }
}


// lib/views/auth/forgot_password_screen.dart (in same file for brevity, split manually)
class ForgotPasswordScreen extends StatefulWidget {
  const ForgotPasswordScreen({super.key});

  @override
  State<ForgotPasswordScreen> createState() => _ForgotPasswordScreenState();
}

class _ForgotPasswordScreenState extends State<ForgotPasswordScreen> {
  bool _sent = false;
  bool _loading = false;

  void _send() {
    setState(() => _loading = true);
    Future.delayed(const Duration(seconds: 2), () {
      setState(() { _loading = false; _sent = true; });
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(leading: const BackButton()),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: _sent ? _successView(context) : _formView(context),
        ),
      ),
    );
  }

  Widget _formView(BuildContext context) => Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
      Container(
        width: 72,
        height: 72,
        decoration: BoxDecoration(color: AppColors.blue.withOpacity(0.2), shape: BoxShape.circle),
        child: const Center(child: Text('🔑', style: TextStyle(fontSize: 36))),
      ),
      const SizedBox(height: 24),
      Text('Forgot Password?', style: Theme.of(context).textTheme.headlineLarge),
      const SizedBox(height: 8),
      Text("No worries! Enter your email and we'll send you a reset link.", style: Theme.of(context).textTheme.bodyMedium?.copyWith(color: AppColors.textSecondary)),
      const SizedBox(height: 36),
      TextFormField(
        initialValue: 'hello@family.com',
        keyboardType: TextInputType.emailAddress,
        decoration: const InputDecoration(labelText: 'Email Address', prefixIcon: Icon(Icons.mail_outline_rounded)),
      ),
      const SizedBox(height: 28),
      GradientButton(label: _loading ? 'Sending...' : 'Send Reset Link', onTap: _loading ? () {} : _send, icon: Icons.send_rounded),
    ],
  );

  Widget _successView(BuildContext context) => Center(
    child: Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Container(
          width: 120,
          height: 120,
          decoration: BoxDecoration(color: AppColors.green, shape: BoxShape.circle),
          child: const Center(child: Text('✉️', style: TextStyle(fontSize: 60))),
        ),
        const SizedBox(height: 28),
        Text('Check your email!', style: Theme.of(context).textTheme.headlineMedium),
        const SizedBox(height: 12),
        Text('We\'ve sent a password reset link to\nhello@family.com', style: Theme.of(context).textTheme.bodyMedium?.copyWith(color: AppColors.textSecondary), textAlign: TextAlign.center),
        const SizedBox(height: 36),
        AppButton(label: 'Back to Login', onTap: () => Get.back()),
        const SizedBox(height: 16),
        TextButton(
          onPressed: _send,
          child: const Text("Didn't receive? Resend", style: TextStyle(color: AppColors.pink, fontWeight: FontWeight.w600)),
        ),
      ],
    ),
  );
}
